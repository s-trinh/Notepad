clc; 
clear all;
close all;
A = [4, 10 ; 6, 8;];
B = [3,  2;  6, 7;];

disp('Matrix A is');
disp(A);

disp('Matrix B is');
disp(B);

AddMatrix = A + B;
disp('Addition of Matrices A and B is');
disp(AddMatrix);

SubMatrix = A - B;
disp('Subtraction of Matrix B from A is');
disp(SubMatrix);

MultMatrix = A*B ;
disp('Array Multiplication of Matrix B from A is');
disp(MultMatrix);

ArrMultMatrix = A.*B ;
disp('Array Multiplication of Matrix A and B is');
disp(ArrMultMatrix);

DivMatrix = A/B ;
disp('Matrix division of Matrix A by B is');
disp(DivMatrix);

ArrDivMatrix = A./B ;
disp('Array Division of Matrix A by B is');
disp(ArrDivMatrix);

GreaterThan = (A(1)>B(1)); 
disp(' Is element 1,1 of A greater than the first element of B ? '); 
disp(GreaterThan); 

LogicalANDOperator = (A(1)>B(1) & A(1)>0); 
disp('Logical Operation : Is element 1,1 of A greater element 1,1 of B, and is element 1,1 of A greater than 0 ?'); 
disp(LogicalANDOperator); 

