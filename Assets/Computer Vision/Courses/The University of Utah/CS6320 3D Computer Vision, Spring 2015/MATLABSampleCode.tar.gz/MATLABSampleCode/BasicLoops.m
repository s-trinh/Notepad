clc; 
clear all;
close all;
ImageMatrix = imread('puppy.jpg');
figure(1); imagesc(ImageMatrix);
sizeX = size(ImageMatrix,1);
sizeY = size(ImageMatrix,2);
ImageNew = zeros(sizeX, sizeY) ;
for i = 1:1:sizeX
    for j = 1:1:sizeY
    if(ImageMatrix(i,j,1)>100)
        ImageNew(i,j,1) = 1;
    elseif(ImageMatrix(i,j,1)<100)
        ImageNew(i,j,1) = -1;
    else
        ImageNew(i,j,1) = 0;
    end
    end
end
figure(2); imagesc(ImageNew);
