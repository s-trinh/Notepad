#include "lab_6.h"
#include "stereo_calibration.h"
#include "sparse_stereo_matcher.h"

#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/viz.hpp"
#include "opencv2/xfeatures2d.hpp"

#include <iomanip>

// Define a few font parameters for convenience.
namespace font
{
  constexpr auto face = cv::FONT_HERSHEY_PLAIN;
  constexpr auto scale = 1.0;
}

// Define a few BGR-colors for convenience.
namespace color
{
  const cv::Scalar green(0, 255, 0);
  const cv::Scalar red(0, 0, 255);
}

/// Capture an image pair from the stereo cameras
/// \param left_cap the left camera
/// \param right_cap the right camera
StereoPair captureStereoPair(cv::VideoCapture& left_cap, cv::VideoCapture& right_cap);

void lab6()
{
  // The calibration files will be in the stereo_calibration folder in a typical CLion setup.
  const std::string intrinsic_filename = "../stereo_calibration/intrinsics.yml";
  const std::string extrinsic_filename = "../stereo_calibration/extrinsics.yml";

  // Make sure that these IDs are correct.
  constexpr int left_camera_id = 1;
  constexpr int right_camera_id = 2;

  // Connect to the cameras.
  cv::VideoCapture left_cap{left_camera_id};
  cv::VideoCapture right_cap{right_camera_id};

  if (!left_cap.isOpened())
  { throw std::runtime_error{"Could not open left camera (id " + std::to_string(left_camera_id) + ")"}; }

  if (!right_cap.isOpened())
  { throw std::runtime_error{"Could not open right camera (id " + std::to_string(right_camera_id) + ")"}; }

  {
    left_cap.set(cv::CAP_PROP_AUTOFOCUS, false);
    left_cap.set(cv::CAP_PROP_FOCUS, 0.375);

    right_cap.set(cv::CAP_PROP_AUTOFOCUS, false);
    right_cap.set(cv::CAP_PROP_FOCUS, 0.375);
  }

  cv::Size img_size;
  {
    // Capture one pair to get img size.
    const auto test_pair = captureStereoPair(left_cap, right_cap);

    if (test_pair.first.size() != test_pair.second.size())
    { throw std::runtime_error("Cameras are not capturing images of the same size."); }

    img_size = test_pair.first.size();
  }

  // Construct calibration object.
  const StereoCalibration calibration{intrinsic_filename, extrinsic_filename, img_size};

  // Construct sparse matcher.
  cv::Ptr<cv::Feature2D> detector = cv::xfeatures2d::SURF::create();
  cv::Ptr<cv::Feature2D> desc_extractor = cv::xfeatures2d::SURF::create();
  SparseStereoMatcher stereo_matcher{detector, desc_extractor};

  // Setup windows.
  const std::string matching_win{"Stereo matching"};
  const std::string depth_win{"Stereo depth"};
  cv::namedWindow(matching_win);
  cv::namedWindow(depth_win);

  cv::viz::Viz3d viz3d{"3D Visualization"};
  constexpr double scale = 0.10;
  viz3d.showWidget("Camera-axis", cv::viz::WCameraPosition(scale));
  viz3d.showWidget("Camera-frustum-left", cv::viz::WCameraPosition(cv::Matx33f(calibration.K_left()), scale));
  viz3d.showWidget("Camera-frustum-right", cv::viz::WCameraPosition(cv::Matx33f(calibration.K_right()), scale), calibration.pose());

  for (;;)
  {
    // Grab raw images
    const StereoPair stereo_raw = captureStereoPair(left_cap, right_cap);

    // Rectify images.
    const StereoPair stereo_rectified = calibration.rectify(stereo_raw);

    // Perform sparse matching.
    // TODO (1/4): Make SparseStereoMatcher::extractGoodMatches() better!
    // TODO (2/4): Compute disparity in SparseStereoMatcher::computeDisparities()
    stereo_matcher.match(stereo_rectified);

    // Visualize the result of the matching.
    cv::Mat visualized_matches;
    cv::Mat first = stereo_rectified.first;
    cv::Mat second = stereo_rectified.second;
    cv::putText(first, "LEFT", {10,20}, font::face, font::scale, color::green);
    cv::putText(second, "RIGHT", {10,20}, font::face, font::scale, color::green);
    cv::drawMatches(first, stereo_matcher.keypoints_left(),
                    second, stereo_matcher.keypoints_right(),
                    stereo_matcher.matches(), visualized_matches,
                    color::green, color::red);
    cv::imshow(matching_win, visualized_matches);

    // Get points with disparities.
    const std::vector<cv::Vec3d>& point_disparities = stereo_matcher.point_disparities();
    if (!point_disparities.empty())
    {
      // Compute depth in meters for each point.
      cv::Mat visualized_depth = stereo_rectified.first.clone();

      const double f = calibration.f();
      const double bx = calibration.baseline();
      for (const auto& d_vec : stereo_matcher.point_disparities())
      {
        constexpr int marker_size = 5;
        const cv::Point pos{
          static_cast<int>(std::round(d_vec[0])), 
          static_cast<int>(std::round(d_vec[1]))
        };
        cv::drawMarker(visualized_depth, pos, color::green, cv::MARKER_CROSS, marker_size);

        // TODO (3/4): Compute and show depth instead.
        const auto disparity = d_vec[2];
        const auto depth = f * bx / disparity;
        std::stringstream depth_text;
        depth_text << std::fixed << std::setprecision(2) << depth;
        cv::putText(visualized_depth, depth_text.str(), pos, font::face, font::scale, color::green);
      }
      cv::imshow(depth_win, visualized_depth);

      // Compute and visualize 3D point cloud.
      std::vector<cv::Vec3d> world_points;

      // TODO (4/4): Use cv::perspectiveTransform() to compute the 3D point cloud instead.
      //world_points.emplace_back(0., 0., 0.); // Do something else!
      cv::perspectiveTransform(point_disparities, world_points, calibration.Q());

      cv::viz::WCloud pointcloud(world_points);
      pointcloud.setRenderingProperty(cv::viz::POINT_SIZE,6);
      viz3d.showWidget("points", pointcloud);
    }

    // Draw visualizations.
    viz3d.spinOnce(10);

    if (cv::waitKey(10) >= 0)
    { break; }
  }
}

StereoPair captureStereoPair(cv::VideoCapture& left_cap, cv::VideoCapture& right_cap)
{
  // Use VideoCapture::grab() to make sure that the images are captured as near in time as possible.
  left_cap.grab();
  right_cap.grab();

  // The captured images are retrieved with VideoCapture::retrieve().
  StereoPair stereo_raw;
  const bool left_ok = left_cap.retrieve(stereo_raw.first);
  const bool right_ok = right_cap.retrieve(stereo_raw.second);

  if (!left_ok) { throw std::runtime_error{"Could not capture from left camera"}; }
  if (!right_ok) { throw std::runtime_error{"Could not capture from right camera"}; }

  return stereo_raw;
}
