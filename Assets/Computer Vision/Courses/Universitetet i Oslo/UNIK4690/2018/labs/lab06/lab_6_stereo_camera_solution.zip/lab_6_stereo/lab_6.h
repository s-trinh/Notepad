#ifndef MASKINSYN_LAB_6_H
#define MASKINSYN_LAB_6_H

#include "opencv2/core.hpp"

void lab6();

#endif //MASKINSYN_LAB_6_H
