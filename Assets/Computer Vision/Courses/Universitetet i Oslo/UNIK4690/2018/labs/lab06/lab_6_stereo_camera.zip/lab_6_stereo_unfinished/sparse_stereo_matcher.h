#ifndef SPARSE_STEREO_MATCHER_H
#define SPARSE_STEREO_MATCHER_H

#include "stereo_calibration.h"
#include "opencv2/features2d.hpp"

class SparseStereoMatcher
{
public:
  SparseStereoMatcher(cv::Ptr<cv::Feature2D> detector,
                      cv::Ptr<cv::Feature2D> desc_extractor,
                      int max_num_features = 100,
                      double max_ratio = 0.9);

  void match(const StereoPair& stereo_img);

  const std::vector<cv::KeyPoint>& keypoints_left() const
  { return keypoints_left_; }

  const std::vector<cv::KeyPoint>& keypoints_right() const
  { return keypoints_right_; }

  const std::vector<cv::DMatch>& matches() const
  { return good_matches_; }

  const std::vector<cv::Vec3d>& point_disparities() const
  { return point_disparities_; }

private:
  void computeDisparities();

  void extractGoodMatches(const std::vector<std::vector<cv::DMatch>>& matches);

  cv::Ptr<cv::Feature2D> detector_;
  cv::Ptr<cv::Feature2D> desc_extractor_;
  cv::Ptr<cv::DescriptorMatcher> matcher_;
  int max_num_features_;
  double max_ratio_;

  std::vector<cv::KeyPoint> keypoints_left_;
  std::vector<cv::KeyPoint> keypoints_right_;
  std::vector<cv::DMatch> good_matches_;
  std::vector<cv::Vec3d> point_disparities_;
};

#endif //SPARSE_STEREO_MATCHER_H
