#ifndef STEREO_CALIBRATION_H
#define STEREO_CALIBRATION_H

#include "opencv2/core.hpp"
#include "opencv2/core/affine.hpp"

// StereoPair.first is the left stereo image, StereoPair.second is the right stereo image.
using StereoPair = std::pair<cv::Mat, cv::Mat>;

class StereoCalibration
{
public:
  StereoCalibration(const std::string& intrinsic_filename,
                    const std::string& extrinsic_filename,
                    const cv::Size& img_size);

  StereoPair rectify(const StereoPair& raw_stereo_pair) const;

  double baseline() const
  { return 1.0 / Q_.at<double>(3, 2); }

  double f() const
  { return Q_.at<double>(2, 3); }

  cv::Size img_size() const
  { return img_size_; }

  const cv::Mat& Q() const
  { return Q_; }

  const cv::Mat& K_left() const
  { return K_left_; }

  const cv::Mat& distortion_left() const
  { return distortion_left_; }

  const cv::Mat& K_right() const
  { return K_right_; }

  const cv::Mat& distortion_right() const
  { return distortion_right_; }

  cv::Affine3d pose() const
  {
    cv::Mat t = -R_.t() * t_;
    return cv::Affine3d(R_.t(), t);
  }

private:
  void computeRectificationMapping();

  cv::Size img_size_;
  cv::Mat Q_;

  // Intrinsics.
  cv::Mat K_left_;
  cv::Mat distortion_left_;
  cv::Mat K_right_;
  cv::Mat distortion_right_;

  // Extrinsics.
  cv::Mat R_;
  cv::Mat t_;

  // Rectification mappings.
  cv::Mat map_left_x_;
  cv::Mat map_left_y_;
  cv::Mat map_right_x_;
  cv::Mat map_right_y_;
};

#endif //STEREO_CALIBRATION_H
