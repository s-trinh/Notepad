#include "multivariate_normal_model.h"

lab9::MultivariateNormalModel::MultivariateNormalModel()
    : is_trained_{false}
{}

bool lab9::MultivariateNormalModel::isTrained() const
{ return is_trained_; }

void lab9::MultivariateNormalModel::performTraining(const cv::Mat& samples)
{
  // TODO 1: Estimate mu_ and inv_covar_(Inverse covariance matrix) from the training samples
  // Hint: See cv::calcCovarMatrix
  is_trained_ = false;
}

cv::Mat lab9::MultivariateNormalModel::computeDensities(const cv::Mat& image)
{
  if (!is_trained_)
  { throw std::runtime_error("You forgot to train the model before trying to compute probability densities!"); }

  // TODO 2: Calculate density value for each pixel in image.
  // Hint: computeMahalanobisDistances is part of the formula (see below)
  cv::Mat density;
  return density;
}

cv::Mat lab9::MultivariateNormalModel::computeMahalanobisDistances(const cv::Mat& image)
{
  cv::Mat image_64;
  image.convertTo(image_64, CV_64FC3);

  cv::Mat mahalanobis_dist(image.size(), CV_64FC1);

  // TODO 3: Calculate mahalanobis distance for each pixel. You will need mu_ and inv_covar_
  // Hint: see cv::Mahalanobis

  return mahalanobis_dist;
}

cv::Mat lab9::segmentImage(const cv::Mat& input_image, int threshold_value, bool use_otsu)
{
  int thresh_type = cv::THRESH_BINARY;
  if (use_otsu)
  { thresh_type |= cv::THRESH_OTSU; }

  cv::Mat segmented_image;
  cv::threshold(input_image, segmented_image, threshold_value, 255, thresh_type);
  return segmented_image;
}

cv::Rect lab9::getSamplingRectangle(cv::Size img_size)
{
  auto start_x = (img_size.width / 2) - (img_size.width / 16);
  auto start_y = (img_size.height / 2) + (2 * img_size.height / 8);
  auto len_x = img_size.width / 8;
  auto len_y = img_size.height / 8;

  return cv::Rect(start_x, start_y, len_x, len_y);
}

cv::Mat lab9::extractTrainingSamples(const cv::Mat& source_image, const cv::Rect sampling_rectangle)
{
  cv::Mat patch = source_image(sampling_rectangle).clone();
  // TODO 4: Experiment with other color spaces and other features
  // Hint: see cv::cvtColor
  cv::Mat samples = patch.reshape(1, patch.rows * patch.cols).t();
  return samples;
}

void lab9::drawSamplingRectangle(cv::Mat& image, cv::Rect sampling_rectangle)
{
  cv::rectangle(image, sampling_rectangle, cv::Scalar{0, 0, 255}, 2);
}
