#include "Eigen/Eigen"
#include <iostream>

int main()
{
  Eigen::Matrix3d mat = Eigen::Matrix3d::Zero();

  std::cout << mat;
}
