#ifndef LAB_7_VO_MATCHER_H
#define LAB_7_VO_MATCHER_H

#include "correspondences.h"
#include "frame.h"

#include "map.h"
#include "opencv2/features2d.hpp"

class Matcher
{
public:
  explicit Matcher(int norm_type, float max_ratio = 0.8f);

  FrameToFrameCorrespondences matchFrameToFrame(const Frame& frame_1, const Frame& frame_2);
  MapToFrameCorrespondences matchMapToFrame(const Map& map, const Frame& frame);

private:
  cv::BFMatcher matcher_;
  float max_ratio_;
};

#endif //LAB_7_VO_MATCHER_H
