#include "lab_7.h"

#include "opencv2/core/eigen.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include "opencv2/xfeatures2d/nonfree.hpp"
#include "two_view_relative_pose_estimator.h"
#include "pnp_pose_estimator.h"
#include "scene_3d.h"
#include "gtsam_pose_estimator.h"
#include <chrono>
#include <iomanip>

// Make shorthand aliases for timing tools.
using Clock = std::chrono::high_resolution_clock;
using DurationInMs = std::chrono::duration<double, std::milli>;

Lab7::Lab7(const IntrinsicCalibration& calibration, int camera_id)
    : cap_{camera_id}
    , calibration_{calibration}
    , detector_{cv::xfeatures2d::SURF::create()}
    , desc_extractor_{detector_}
    , matcher_{desc_extractor_->defaultNorm()}
{
  if (!cap_.isOpened())
  {
    throw std::runtime_error("Could not open camera " + std::to_string(camera_id));
  }
}

void Lab7::run()
{
  // Todo: Finish TwoViewRelativePoseEstimator::estimate()
  // Create the 2d-2d relative pose estimator.
  // We will use this for map creation.
  TwoViewRelativePoseEstimator frame_to_frame_pose_estimator{calibration_.K_cv()};

  // Create the 3d-2d pose estimator.
  // We will use this to navigate in maps between keyframes.
  // Use the PnPPoseEstimator alone if you can't use GTSAM.
  GtsamPoseEstimator pose_estimator(std::make_shared<PnPPoseEstimator>(calibration_.K()), calibration_.K());

  // Create 3d scene visualization.
  Scene3D scene_3d(calibration_.K_cv());

  // Construct empty pointers to hold frames and maps.
  std::shared_ptr<Frame> active_keyframe;
  std::shared_ptr<Frame> tracking_frame;
  std::shared_ptr<Map> active_map;
  std::shared_ptr<Map> init_map;

  for (;;)
  {
    auto start = Clock::now();

    // Captures and makes the frame ready for matching.
    tracking_frame = captureFrame();

    // Construct image for visualization.
    cv::Mat vis_img = tracking_frame->image();

    // If we have an active map, track the frame using 3d-2d correspondences.
    if (active_map)
    {
      // Compute 3d-2d correspondences.
      const auto corr = matcher_.matchMapToFrame(*active_map, *tracking_frame);

      // Estimate pose from 3d-2d correspondences.
      PoseEstimate estimate = pose_estimator.estimate(corr.frame_points(), corr.map_points());

      if (estimate.isFound())
      {
        // Update frame pose with 3d-2d estimate.
        tracking_frame->setPose(estimate.pose_W_C);

        // Visualize tracking.
        scene_3d.updateTrackingFrame(estimate);
        for (const auto& point : estimate.image_inlier_points)
        {
          cv::drawMarker(vis_img, point, {0, 255, 0}, cv::MARKER_CROSS, 5);
        }
      }
    }

    // If we only have one active keyframe and no map,
    // visualize the map initialization from 2d-2d correspondences.
    else if (active_keyframe)
    {
      // Compute 2d-2d correspondences.
      auto corr = matcher_.matchFrameToFrame(*active_keyframe, *tracking_frame);

      // Todo: Finish TwoViewRelativePoseEstimator::estimate()
      // Estimate pose from 2d-2d correspondences.
      const auto estimate = frame_to_frame_pose_estimator.estimate(corr);

      if (estimate.isFound())
      {
        // Update frame poses with 2d-2d estimate (first camera is origin).
        active_keyframe->setPose(Sophus::SE3d{});
        tracking_frame->setPose(estimate.pose());

        // Compute an initial 3d map from the correspondences by using the epipolar geometry.
        init_map = createMap(active_keyframe, tracking_frame, estimate.inliers());

        if (init_map)
        {
          // Visualize inital 3d map with relative poses.
          scene_3d.setInitialMap(*init_map);

          const auto& pt1 = estimate.inliers().points_1();
          const auto& pt2 = estimate.inliers().points_2();
          for (size_t i = 0; i < estimate.inliers().size(); ++i)
          {
            cv::line(vis_img, pt1[i], pt2[i], {255, 0, 0});
            cv::drawMarker(vis_img, pt1[i], {255, 255, 255}, cv::MARKER_CROSS, 5);
            cv::drawMarker(vis_img, pt2[i], {255, 0, 255}, cv::MARKER_CROSS, 5);
          }
        }
      }
    }

    // Stop the clock and print the processing time in the frame.
    auto end = Clock::now();
    DurationInMs duration = end - start;
    std::stringstream corr_duration_txt;
    corr_duration_txt << std::fixed << std::setprecision(0);
    corr_duration_txt << "Processing: " << duration.count() << "ms";
    cv::putText(vis_img, corr_duration_txt.str(), {10, 20}, cv::FONT_HERSHEY_PLAIN, 1.0, {0, 0, 255});
    cv::imshow("Test", vis_img);

    // Get input from keyboard.
    const auto key = cv::waitKey(10);
    if (key == ' ')
    {
      if (!active_keyframe)
      {
        // Set active keyframe.
        active_keyframe = tracking_frame;
      }
      else if (!active_map)
      {
        // Set active map.
        active_map = init_map;
        active_keyframe = active_map->frame_2;
      }
      else
      {
        // Add a new consecutive map as an odometry step.
        if (tracking_frame->hasPose())
        {
          // Use 2d-2d pose estimator to extract inliers for map point triangulation.
          const auto estimate = frame_to_frame_pose_estimator.estimate(
              matcher_.matchFrameToFrame(*active_keyframe, *tracking_frame));

          // Try to create a new map based on the 2d-2d inliers.
          auto new_map = createMap(active_keyframe, tracking_frame, estimate.inliers());

          if (new_map)
          {
            // Update map.
            active_map = new_map;
            active_keyframe = tracking_frame;
            scene_3d.addMap(*new_map);
          }
        }
      }
    }
    else if (key == 'r')
    {
      // Reset.
      // Make all reference data empty.
      active_keyframe = nullptr;
      active_map = nullptr;
      scene_3d.reset();
    }
    else if (key > 0)
    {
      // Quit.
      break;
    }

    // Update the 3d visualization.
    scene_3d.update();
  }
}

std::shared_ptr<Frame> Lab7::captureFrame()
{
  cv::Mat distorted_image;
  cap_ >> distorted_image;

  if (distorted_image.empty())
  {
    throw std::runtime_error("Could not capture from camera");
  }

  return std::make_shared<Frame>(calibration_, distorted_image, detector_, desc_extractor_);
}
