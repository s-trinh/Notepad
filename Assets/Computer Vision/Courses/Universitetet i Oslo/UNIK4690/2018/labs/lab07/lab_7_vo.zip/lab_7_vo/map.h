#ifndef LAB_7_VO_MAP_H
#define LAB_7_VO_MAP_H

#include "frame.h"
#include "correspondences.h"
#include "opencv2/core.hpp"

struct Map
{
  Map(std::shared_ptr<Frame> frame_1,
      std::shared_ptr<Frame> frame_2,
      const std::vector<cv::Point3f>& world_points,
      cv::Mat world_descriptors);

  std::shared_ptr<Frame> frame_1;
  std::shared_ptr<Frame> frame_2;
  std::vector<cv::Point3f> world_points;
  cv::Mat descriptors;
};

std::shared_ptr<Map> createMap(std::shared_ptr<Frame> frame_1,
                               std::shared_ptr<Frame> frame_2,
                               const FrameToFrameCorrespondences& corr);

#endif //LAB_7_VO_MAP_H
