#include "lab_7.h"
#include <iostream>



IntrinsicCalibration setupCameraCalibration()
{
  // Todo: Remember to set correct intrinsic calibration!
  cv::Matx33d K
      {6.4858359326318134e+02, 0., 3.2467487030979549e+02,
       0., 6.4858359326318134e+02, 2.5194306349757946e+02,
       0., 0., 1.};

  // Set distortion coefficients [k1, k2, 0, 0, k3].
  cv::Vec5d dist_coeffs{
      -4.0729183827148754e-02, 4.0439764267947936e-01, 0., 0., -7.5463632556792393e-01 };

  return {K, dist_coeffs};
}

int main()
{
  try
  {
    constexpr int camera_id = 1;
    Lab7 lab(setupCameraCalibration(), camera_id);
    lab.run();
  }
  catch (const std::exception& e)
  {
    std::cerr << "Caught exception:\n"
              << e.what() << "\n";
  }
  catch (...)
  {
    std::cerr << "Caught unknown exception\n";
  }

  return EXIT_SUCCESS;
}
