#ifndef LAB_4_MOSAIC_LAB_4_H
#define LAB_4_MOSAIC_LAB_4_H

void lab4();

#endif //LAB_4_MOSAIC_LAB_4_H
