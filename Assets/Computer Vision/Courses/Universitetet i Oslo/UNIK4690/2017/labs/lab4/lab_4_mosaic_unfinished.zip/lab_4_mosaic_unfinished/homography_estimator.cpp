#include "homography_estimator.h"
#include "opencv2/core/eigen.hpp"
#include "Eigen/Eigen"

cv::Mat HomographyEstimator::estimate(const PointList& pts1, const PointList& pts2)
{
  // Find inliers.
  PointSelection is_inlier = ransacEstimator(pts1, pts2);

  // Estimate homography from set of inliers.
  Eigen::Matrix3f H = normalizedDltEstimator(samplePoints(pts1, is_inlier), samplePoints(pts2, is_inlier));

  // Convert to cv::Mat and return homography.
  cv::Mat res;
  cv::eigen2cv(H, res);
  return res.clone();
}

PointSelection HomographyEstimator::ransacEstimator(const PointList& pts1, const PointList& pts2)
{
  long best_num_inliers{0};
  PointSelection best_inliers(pts1.size());
  PointSelection test_inliers(pts1.size());
  Eigen::Matrix3f best_homography;
  Eigen::Matrix3f test_homography;
  Eigen::Matrix3f test_homography_inv;

  double max_iterations = std::numeric_limits<double>::max();
  for (int iterations = 0; iterations < max_iterations; ++iterations)
  {
    // Sample 4 random points.
    PointSelection rand_selection = randomlySelectPoints(pts1.size(), 4);

    // Determine test homography.
    test_homography = dltEstimator(samplePoints(pts1, rand_selection), samplePoints(pts2, rand_selection));
    test_homography_inv = test_homography.inverse();

    // Count number of inliers.
    long test_num_inliers{0};
    std::fill(test_inliers.begin(), test_inliers.end(), 0);
    for (size_t i=0; i < pts1.size(); ++i)
    {
      if (reprojectionError(pts1[i], pts2[i], test_homography, test_homography_inv) < distance_threshold_)
      {
        test_inliers[i] = 1;
        test_num_inliers++;
      }
    }

    // Update homography if test_homography has the most inliers so far
    if (test_num_inliers > best_num_inliers)
    {
      // Update circle with largest inlier set.
      std::swap(best_homography, test_homography);
      std::swap(best_inliers, test_inliers);
      best_num_inliers = test_num_inliers;

      // Update max iterations.
      double inlier_ratio = static_cast<double>(best_num_inliers) / static_cast<double>(pts1.size());
      max_iterations = std::log(1.f - p_) / std::log(1.f - inlier_ratio*inlier_ratio*inlier_ratio*inlier_ratio);
    }
  }

  return best_inliers;
}

Eigen::Matrix3f HomographyEstimator::dltEstimator(const PointList& pts1, const PointList& pts2)
{
  // Construct the equation matrix.
  Eigen::MatrixXf A(2 * pts1.size(), 9);
  for (size_t i = 0; i < pts1.size(); ++i)
  {
    A.row(2 * i) << 0.f, 0.f, 0.f, -pts1[i].x, -pts1[i].y, -1.f, pts2[i].y*pts1[i].x, pts2[i].y*pts1[i].y, pts2[i].y;
    A.row(2 * i+1) << pts1[i].x, pts1[i].y, 1.f, 0.f, 0.f, 0.f, -pts2[i].x*pts1[i].x, -pts2[i].x*pts1[i].y, -pts2[i].x;
  }

  // Solve using SVD.
  Eigen::VectorXf h = A.jacobiSvd(Eigen::ComputeThinU | Eigen::ComputeFullV).matrixV().rightCols<1>();

  // Create homography matrix from solution.
  Eigen::Matrix3f H;
  H << h(0), h(1), h(2),
      h(3), h(4), h(5),
      h(6), h(7), h(8);

  // Standardize H
  if (H(2, 2) != 0)
    H *= (1.f / H(2, 2));

  return H;
}

Eigen::Matrix3f HomographyEstimator::normalizedDltEstimator(const PointList& pts1, const PointList& pts2)
{
  // Normalize points
  Eigen::Matrix3f S1 = findNormalizingSimilarity(pts1);
  PointList pts1_normalized = performMapping(pts1, S1);

  Eigen::Matrix3f S2 = findNormalizingSimilarity(pts2);
  PointList pts2_normalized = performMapping(pts2, S2);

  // Estimate the homography.
  Eigen::Matrix3f H = dltEstimator(pts1_normalized, pts2_normalized);

  // Transform back to the original frame.
  H = S2.inverse()*H*S1;

  // Standardize H
  if (H(2, 2) != 0)
  {
    H *= (1.f / H(2, 2));
  }

  return H;
}

Eigen::Matrix3f HomographyEstimator::findNormalizingSimilarity(const PointList& pts)
{
  // Centroid of points
  cv::Scalar center = cv::mean(pts);

  // Compute the mean distance from centroid for all pts
  double r_tot = 0;
  for (size_t i = 0; i < pts.size(); ++i)
  {
    r_tot += sqrt((pts[i].x - center(0))*(pts[i].x - center(0)) + (pts[i].y - center(1))*(pts[i].y - center(1)));
  }
  double r_mean = r_tot / pts.size();

  // The normalizing similarity matrix S
  double s = sqrt(2) / r_mean;
  Eigen::Matrix3f S;
  S << s, 0.f, -s*center(0),
      0.f, s, -s*center(1),
      0.f, 0.f, 1.f;

  return S;
}

PointList HomographyEstimator::samplePoints(const PointList& pts, const PointSelection& selection)
{
  PointList samples;

  for (size_t i = 0; i < selection.size(); ++i)
  {
    if (selection[i])
    {
      samples.push_back(pts[i]);
    }
  }
  return samples;
}

PointList HomographyEstimator::performMapping(const PointList& pts, const Eigen::Matrix3f& T)
{
  PointList mapped(pts.size());
  for (size_t i=0; i < pts.size(); ++i)
  {
    mapped[i] = performMapping(pts[i], T);
  }

  return mapped;
}

PointSelection HomographyEstimator::randomlySelectPoints(size_t total_size, int sample_size)
{
  PointSelection is_drawn(total_size, 0);
  std::uniform_int_distribution<size_t> distribution(0, total_size-1);

  for (int i=0; i < sample_size; ++i)
  {
    size_t index = distribution(generator_);
    while (is_drawn[index] > 0)
    {
      index = distribution(generator_);
    }
    is_drawn[index] = 1;
  }

  return is_drawn;
}

