#ifndef LAB4_HOMOGRAPHY_ESTIMATOR_H
#define LAB4_HOMOGRAPHY_ESTIMATOR_H

#include "opencv2/opencv.hpp"
#include "Eigen/Dense"
#include <random>

using PointList = std::vector<cv::Point2f>;
using PointSelection = std::vector<uint8_t>;

class HomographyEstimator
{
public:
  HomographyEstimator() : HomographyEstimator(0.99, 3)
  { }

  HomographyEstimator(float p, float distance_threshold)
      : p_{p}
      , distance_threshold_{distance_threshold}
      , rd_{}
      , generator_{rd_()}
  { }

  /// Estimate homography (3x3 perspective transformation) from point correspondences.
  cv::Mat estimate(const PointList& pts1, const PointList& pts2);

private:
  PointSelection ransacEstimator(const PointList& pts1, const PointList& pts2);
  Eigen::Matrix3f dltEstimator(const PointList& pts1, const PointList& pts2);
  Eigen::Matrix3f normalizedDltEstimator(const PointList& pts1, const PointList& pts2);
  Eigen::Matrix3f findNormalizingSimilarity(const PointList& pts);

  float reprojectionError(const cv::Point2f& pt1, const cv::Point2f& pt2,
                          const Eigen::Matrix3f& H, const Eigen::Matrix3f& H_inv);

  PointList samplePoints(const PointList& pts, const PointSelection& selection);
  cv::Point2f performMapping(const cv::Point2f& pt, const Eigen::Matrix3f& T);
  PointList performMapping(const PointList& pts, const Eigen::Matrix3f& T);
  PointSelection randomlySelectPoints(size_t total_size, int sample_size);

  float p_;
  float distance_threshold_;
  std::random_device rd_;
  std::mt19937 generator_;
};

inline float HomographyEstimator::reprojectionError(const cv::Point2f& pt1, const cv::Point2f& pt2,
                                                    const Eigen::Matrix3f& H, const Eigen::Matrix3f& H_inv)
{
  Eigen::Vector2f vec_1(pt1.x, pt1.y);
  Eigen::Vector2f vec_1_in_2 = (H*vec_1.homogeneous()).hnormalized();

  Eigen::Vector2f vec_2(pt2.x, pt2.y);
  Eigen::Vector2f vec_2_in_1 = (H_inv*vec_2.homogeneous()).hnormalized();

  return (vec_1 - vec_2_in_1).norm() + (vec_2 - vec_1_in_2).norm();
}

inline cv::Point2f HomographyEstimator::performMapping(const cv::Point2f& pt, const Eigen::Matrix3f& T)
{
  Eigen::Vector3f pt_h{pt.x, pt.y, 1.f};
  Eigen::Vector2f mapped_pt = (T*pt_h).hnormalized();
  return {mapped_pt(0), mapped_pt(1)};
}


#endif
