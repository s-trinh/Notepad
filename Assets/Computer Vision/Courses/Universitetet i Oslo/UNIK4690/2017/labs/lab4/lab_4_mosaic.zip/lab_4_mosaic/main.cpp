#include "homography_estimator.h"
#include "opencv2/xfeatures2d.hpp"
#include "opencv2/features2d.hpp"
#include <chrono>

std::vector<cv::DMatch> extract_good_ratio_matches(
  const std::vector<std::vector<cv::DMatch>>& matches, double max_ratio)
{
  std::vector<cv::DMatch> good_ratio_matches;

  for (size_t i = 0; i < matches.size(); ++i)
  {
    if (matches[i][0].distance < matches[i][1].distance * max_ratio)
      good_ratio_matches.push_back(matches[i][0]);
  }

  return good_ratio_matches;
}

void extract_matching_points(
  const std::vector<cv::KeyPoint>& keypts1,
  const std::vector<cv::KeyPoint>& keypts2,
  const std::vector<cv::DMatch>& matches,
  std::vector<cv::Point2f>& matched_pts1,
  std::vector<cv::Point2f>& matched_pts2)
{
  matched_pts1.clear();
  matched_pts2.clear();
  for (size_t i = 0; i < matches.size(); ++i)
  {
    matched_pts1.push_back(keypts1[matches[i].queryIdx].pt);
    matched_pts2.push_back(keypts2[matches[i].trainIdx].pt);
  }
}

int main()
{
  cv::VideoCapture cap{1};
  if (!cap.isOpened()) {
    std::cerr << "Could not open VideoCapture\n";
    return -1;
  }

  // Set up objects for detection, description and matching.
  cv::Ptr<cv::Feature2D> detector = cv::xfeatures2d::SURF::create();
  cv::Ptr<cv::Feature2D> desc_extractor = cv::xfeatures2d::SURF::create();
  cv::BFMatcher matcher{desc_extractor->defaultNorm()};

  // Set up windows.
  std::string match_win = "Lab 4: Feature matching";
  cv::namedWindow(match_win);
  std::string mosaic_win = "Lab 4: Mosaic";
  cv::namedWindow(mosaic_win);

  // Base image for mosaic.
  cv::Mat base_img;
  std::vector<cv::KeyPoint> base_keypoints;
  cv::Mat base_descriptors;
  HomographyEstimator estimator;

  // Question: What does this similarity transform do?
  int frame_cols = static_cast<int>(cap.get(cv::CAP_PROP_FRAME_WIDTH));
  int frame_rows = static_cast<int>(cap.get(cv::CAP_PROP_FRAME_HEIGHT));
  cv::Matx33d S{
      0.5, 0.0, 0.25 * frame_cols,
      0.0, 0.5, 0.25 * frame_rows,
      0.0, 0.0, 1.0};

  for (;;)
  {
    cv::Mat frame;
    cap >> frame;

    // Start clock.
    auto start = std::chrono::high_resolution_clock::now();

    cv::Mat gray_frame;
    cv::cvtColor(frame, gray_frame, cv::COLOR_BGR2GRAY);

    // Detect keypoints.
    std::vector<cv::KeyPoint> frame_keypoints;
    detector->detect(gray_frame, frame_keypoints);
    cv::KeyPointsFilter::retainBest(frame_keypoints, 500);

    cv::Mat feature_vis;
    cv::drawKeypoints(frame, frame_keypoints, feature_vis, cv::Scalar{0,255,0});

    // Perform matching and homography estimation for mosaicking two images together.
    if (!base_descriptors.empty())
    {
      cv::Mat frame_descriptors;
      std::vector<std::vector<cv::DMatch>> matches;

      // Match descriptors with ratio test.
      desc_extractor->compute(gray_frame, frame_keypoints, frame_descriptors);
      matcher.knnMatch(frame_descriptors, base_descriptors, matches, 2);
      std::vector<cv::DMatch> good_matches = extract_good_ratio_matches(matches, 0.8);

      cv::drawMatches(frame, frame_keypoints, base_img, base_keypoints, good_matches, feature_vis);

      if (good_matches.size() >= 10)
      {
        // Extract pixel coordinates for corresponding points.
        std::vector<cv::Point2f> matching_pts1;
        std::vector<cv::Point2f> matching_pts2;
        extract_matching_points(frame_keypoints, base_keypoints, good_matches, matching_pts1, matching_pts2);

        // Estimate homography.
        cv::Matx33d H = estimator.estimate(matching_pts1, matching_pts2);

        // Insert a downscaled base image into the mosiac.
        cv::Mat mosaic;
        cv::warpPerspective(base_img, mosaic, S, frame.size());

        // Insert the current frame into the mosaic.
        cv::Mat frame_warp;
        cv::warpPerspective(frame, frame_warp, S * H, frame.size());
        cv::Mat mask = frame_warp > 0;
        cv::erode(mask, mask, cv::Mat());
        frame_warp.copyTo(mosaic, mask);

        // Show mosaicking result.
        cv::imshow(mosaic_win, mosaic);
      }
    }

    // Stop clock and print duration.
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> diff = end-start;
    std::stringstream duration_info;
    duration_info << "Frame processing time: "
       << std::chrono::duration_cast<std::chrono::milliseconds>(diff).count()
       << "ms";
    cv::putText(feature_vis, duration_info.str(), {10, 20}, cv::FONT_HERSHEY_PLAIN, 1.0, {0, 0, 255});

    // Show feature matching visualization.
    cv::imshow(match_win, feature_vis);

    int key = cv::waitKey(30);
    if (key == ' ')
    {
      // Set base image for mosaic.
      base_img = frame.clone();
      base_keypoints = frame_keypoints;
      desc_extractor->compute(gray_frame, base_keypoints, base_descriptors);
    }
    else if (key == 'r')
    {
      // Reset.
      base_img = cv::Mat{};
      base_keypoints.clear();
      base_descriptors = cv::Mat{};
    }
    else if (key > 0) break;
  }
}
