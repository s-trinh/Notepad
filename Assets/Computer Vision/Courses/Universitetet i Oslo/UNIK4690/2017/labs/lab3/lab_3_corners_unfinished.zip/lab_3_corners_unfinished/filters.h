#ifndef LAB_3_CORNERS_FILTERS_H
#define LAB_3_CORNERS_FILTERS_H

#include "opencv2/core.hpp"

cv::Mat gaussian_kernel(double sigma, int radius = 0);

cv::Mat derivated_gaussian_kernel(double sigma, int radius = 0);

#endif //LAB_3_CORNERS_FILTERS_H
