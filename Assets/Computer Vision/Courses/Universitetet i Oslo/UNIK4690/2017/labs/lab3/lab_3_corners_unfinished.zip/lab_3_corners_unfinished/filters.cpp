#include "filters.h"

cv::Mat gaussian_kernel(double sigma, int radius)
{
  if (radius <= 0) radius = static_cast<int>(std::ceil(3.5 * sigma));

  int length = 2*radius + 1;

  cv::Mat kernel{length, 1, CV_64F};
  double* element = kernel.ptr<double>();

  double scale{-0.5 / (sigma*sigma)};
  double sum{0};
  for (int i = 0; i < length; ++i)
  {
    int x = i - radius;
    element[i] = std::exp(x * x * scale);
    sum += element[i];
  }

  kernel /= sum;
  return kernel;
}

//TODO STEP 1: Finish function.
cv::Mat derivated_gaussian_kernel(double sigma, int radius)
{
  return cv::Mat{};
}