#include "corner_detector.h"

std::vector<cv::KeyPoint> CornerDetector::detect(cv::Mat image) const
{
  cv::Mat Ix;
  cv::Mat Iy;

  //TODO STEP 2: Estimate image gradients Ix and Iy using g_kernel_ and dg_kernel.

  //TODO STEP 3: Compute the elements of M; A, B and C from Ix and Iy.
  cv::Mat A;
  cv::Mat B;
  cv::Mat C;

  //TODO STEP 3: Apply the windowing gaussian win_kernel on A, B and C.

  //TODO STEP 4: Finish all the corner response functions.
  cv::Mat response;
  switch (metric_type_)
  {
  case CornerMetric::harris:
    response = harris_metric(A, B, C); break;

  case CornerMetric::harmonic_mean:
    response = harmonic_mean_metric(A, B, C); break;

  case CornerMetric::min_eigen:
    response = min_eigen_metric(A, B, C); break;
  }

  //TODO STEP 5: Compute the threshold by using quality_level_ on the maximum response.

  //TODO STEP 5: Threshold the response.

  //TODO STEP 6: Find the local maxima, and extract corners.
  std::vector<cv::KeyPoint> key_points;

  return key_points;
}

//TODO STEP 4: Finish function.
cv::Mat CornerDetector::harris_metric(cv::Mat& A, cv::Mat& B, cv::Mat& C) const
{
  return cv::Mat{};
}

//TODO STEP 4: Finish function.
cv::Mat CornerDetector::harmonic_mean_metric(cv::Mat& A, cv::Mat& B, cv::Mat& C) const
{
  return cv::Mat{};
}

//TODO STEP 4: Finish function.
cv::Mat CornerDetector::min_eigen_metric(cv::Mat& A, cv::Mat& B, cv::Mat& C) const
{
  return cv::Mat{};
}

