#include <chrono>
#include "corner_detector.h"

int main()
{
  const int camera_id = 1; // Second camera on lab PCs.
  cv::VideoCapture cap{camera_id};
  if (!cap.isOpened())
  {
    std::cerr << "Could not open camera\n";
  }

  const std::string win_name = "Lab 3: Corner detection";
  cv::namedWindow(win_name);

  CornerDetector det;
  for (;;)
  {
    cv::Mat frame;
    cap >> frame;

    cv::Mat gray_frame;
    cv::cvtColor(frame, gray_frame, cv::COLOR_BGR2GRAY);

    std::vector<cv::KeyPoint> corners = det.detect(gray_frame);
    cv::KeyPointsFilter::retainBest(corners, 500);

    cv::Mat vis_img;
    cv::drawKeypoints(frame, corners, vis_img, cv::Scalar{0,255,0});

    //TODO STEP 8: Estimate circle from corners.

    cv::imshow(win_name, vis_img);
    if (cv::waitKey(30) >= 0) break;
  }
}
