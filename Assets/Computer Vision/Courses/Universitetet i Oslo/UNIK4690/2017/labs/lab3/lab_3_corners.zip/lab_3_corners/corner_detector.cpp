#include "corner_detector.h"

std::vector<cv::KeyPoint> CornerDetector::detect(cv::Mat image) const
{
  cv::Mat Ix;
  cv::Mat Iy;

  // Estimate image gradients Ix and Iy using g_kernel_ and dg_kernel.
  cv::sepFilter2D(image, Ix, CV_32F, dg_kernel_, g_kernel_);
  cv::sepFilter2D(image, Iy, CV_32F, g_kernel_, dg_kernel_);

  // Compute the elements of M; A, B and C from Ix and Iy.
  cv::Mat A = Ix.mul(Ix);
  cv::Mat B = Ix.mul(Iy);
  cv::Mat C = Iy.mul(Iy);

  // Apply the windowing gaussian win_kernel on A, B and C.
  cv::sepFilter2D(A, A, -1, win_kernel, win_kernel);
  cv::sepFilter2D(B, B, -1, win_kernel, win_kernel);
  cv::sepFilter2D(C, C, -1, win_kernel, win_kernel);

  // Compute corner response.
  cv::Mat response;
  switch (metric_type_)
  {
  case CornerMetric::harris:
    response = harrisMetric(A, B, C); break;

  case CornerMetric::harmonic_mean:
    response = harmonicMeanMetric(A, B, C); break;

  case CornerMetric::min_eigen:
    response = minEigenMetric(A, B, C); break;
  }

  // Compute the threshold by using quality_level_ on the maximum response.
  double max_val{0};
  cv::minMaxLoc(response, nullptr, &max_val);

  // Threshold the response.
  cv::threshold(response, response, max_val * quality_level_, 0, cv::THRESH_TOZERO);

  // Find the local maxima, and extract corners.
  cv::Mat local_max;
  cv::dilate(response, local_max, cv::Mat{});

  cv::Size img_size = image.size();
  std::vector<cv::KeyPoint> key_points;
  float keypoint_size = static_cast<float>(3.0 * window_sigma_);
  for (int y = 1; y < img_size.height - 1; ++y)
  {
    for (int x = 1; x < img_size.width - 1; ++x)
    {
      float val = response.at<float>(y, x);
      float local_max_val = local_max.at<float>(y, x);

      if (val != 0 && val == local_max_val)
      {
        cv::Point2f point{static_cast<float>(x), static_cast<float>(y)};
        key_points.push_back(cv::KeyPoint{point, keypoint_size, -1, val});
      }
    }
  }

  return key_points;
}

cv::Mat CornerDetector::harrisMetric(cv::Mat& A, cv::Mat& B, cv::Mat& C) const
{
  double alpha = 0.06;
  cv::Mat det_M = A.mul(C) - B.mul(B);
  cv::Mat trc_M = A + C;

  return det_M - alpha*(trc_M).mul(trc_M);
}

cv::Mat CornerDetector::harmonicMeanMetric(cv::Mat& A, cv::Mat& B, cv::Mat& C) const
{
  cv::Mat det_M = A.mul(C) - B.mul(B);
  cv::Mat trc_M = A + C;

  return det_M.mul(1.0 / trc_M);
}

cv::Mat CornerDetector::minEigenMetric(cv::Mat& A, cv::Mat& B, cv::Mat& C) const
{
  cv::Mat root;
  cv::sqrt(4 * B.mul(B) + (A - C).mul(A - C), root);
  return 0.5*((A + C) - root);
}

