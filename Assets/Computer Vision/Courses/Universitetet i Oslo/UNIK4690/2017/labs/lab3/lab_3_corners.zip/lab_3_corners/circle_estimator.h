#ifndef LAB_3_CIRCLE_ESTIMATOR_H
#define LAB_3_CIRCLE_ESTIMATOR_H

#include "circle.h"
#include "opencv2/opencv.hpp"

class CircleEstimator
{
public:
  CircleEstimator() : CircleEstimator(0.99, 5.0) {}

  CircleEstimator(double p, double distance_threshold)
      : p_{p}, distance_threshold_{distance_threshold}, last_number_of_iterations_{0}
  {}

  void detectAndVisualizeCircle(cv::Mat& img, const std::vector<cv::KeyPoint>& keypoints);

private:

  Circle ransacEstimator(const std::vector<cv::Point2f>& pts);

  Circle leastSquaresEstimator(const std::vector<cv::Point2f>& pts);

  std::vector<cv::Point2f> extractInlierPoints(const Circle& circle, const std::vector<cv::Point2f>& pts);

  double p_;
  double distance_threshold_;
  int last_number_of_iterations_;
};

#endif
