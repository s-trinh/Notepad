#ifndef LAB_3_CORNERS_CIRCLE_H
#define LAB_3_CORNERS_CIRCLE_H

#include "Eigen/Eigen"
#include "opencv2/core.hpp"

struct Circle
{
  double x0;
  double y0;
  double radius;

  /// Constructs an empty circle.
  Circle() : Circle(0.0, 0.0, 0.0)
  { }

  /// Constructs a circle from a center point and a radius.
  Circle(double x0, double y0, double radius)
      : x0{x0}, y0{y0}, radius{radius}
  { }

  /// Constructs a circle from a center point and a radius.
  Circle(Eigen::Vector2d center_point, double radius)
      : x0{center_point(0)}, y0{center_point(1)}, radius{radius}
  { }

  /// Constructs a circle from three points on the circle.
  Circle(Eigen::Vector2d p1, Eigen::Vector2d p2, Eigen::Vector2d p3)
  {
    // p1 and p2 define line_1 as their center line
    Eigen::Vector2d m1 = 0.5*(p1 + p2);
    Eigen::Vector2d q1{m1(0) + p2(1) - p1(1), m1(1) - p2(0) + p1(0)};
    Eigen::Vector3d line_1 = m1.homogeneous().cross(q1.homogeneous());

    // p2 and p3 define the line_2 as their center line
    Eigen::Vector2d m2 = 0.5*(p2 + p3);
    Eigen::Vector2d q2{m2(0) + p3(1) - p2(1), m2(1) - p3(0) + p2(0)};
    Eigen::Vector3d line_2 = m2.homogeneous().cross(q2.homogeneous());

    // Determine circle
    Eigen::Vector2d center_point = line_1.cross(line_2).hnormalized();

    x0 = center_point(0);
    y0 = center_point(1);
    radius = (p1 - center_point).norm();
  }

  /// Returns the distance between the circle and a point.
  double distance(cv::Point2f point) const
  {
    return std::abs(std::sqrt((point.x - x0)*(point.x - x0) + (point.y - y0)*(point.y - y0)) - radius);
  }
};

#endif //LAB_3_CORNERS_CIRCLE_H
