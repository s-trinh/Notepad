#include "circle_estimator.h"

void CircleEstimator::detectAndVisualizeCircle(cv::Mat& img, const std::vector<cv::KeyPoint>& keypoints)
{
  if (keypoints.size() < 3)
  {
    // Too few points to estimate any circle.
    return;
  }

  // Convert to points.
  std::vector<cv::Point2f> pts;
  cv::KeyPoint::convert(keypoints, pts);

  // Estimate circle
  Circle ransac_circle = ransacEstimator(pts);
  std::vector<cv::Point2f> inlier_pts = extractInlierPoints(ransac_circle, pts);
  Circle circle = leastSquaresEstimator(inlier_pts);

  // Draw inliers
  std::vector<cv::KeyPoint> inlier_keypts;
  cv::KeyPoint::convert(inlier_pts, inlier_keypts); // Convert back to keypoints for convenience.
  cv::drawKeypoints(img, inlier_keypts, img, cv::Scalar{0,0,255});

  // Draw circle
  cv::Point center_point{static_cast<int>(circle.x0), static_cast<int>(circle.y0)};
  int radius = static_cast<int>(circle.radius);
  cv::circle(img, center_point, radius, cv::Scalar(0, 0, 255), cv::LINE_4, cv::LINE_AA);

  // Print some information about the estimation.
  std::stringstream iterations_info;
  iterations_info << "Iterations: " << last_number_of_iterations_;
  cv::putText(img, iterations_info.str(), {10, 20}, cv::FONT_HERSHEY_PLAIN, 1.0, {0, 0, 255});

  std::stringstream inliers_info;
  inliers_info << "Inliers: " << inlier_pts.size();
  cv::putText(img, inliers_info.str(), {10, 40}, cv::FONT_HERSHEY_PLAIN, 1.0, {0, 0, 255});
}

Circle CircleEstimator::ransacEstimator(const std::vector<cv::Point2f>& pts)
{
  long best_num_inliers{0};
  Circle best_circle;

  int max_iterations = std::numeric_limits<int>::max();

  int iterations = 0;
  for (; iterations < max_iterations; ++iterations)
  {
    // Sample 3 random points
    const cv::Point2f& p1 = pts[std::rand() % pts.size()];
    const cv::Point2f& p2 = pts[std::rand() % pts.size()];
    const cv::Point2f& p3 = pts[std::rand() % pts.size()];

    // Determine test circle
    Circle tst_circle{Eigen::Vector2d{p1.x, p1.y},
                      Eigen::Vector2d{p2.x, p2.y},
                      Eigen::Vector2d{p3.x, p3.y}};

    // Count number of inliers.
    long tst_num_inliers = std::count_if(
        pts.begin(), pts.end(),
        [&tst_circle, this](const cv::Point2f& point)
        {
          return tst_circle.distance(point) < distance_threshold_;
        });

    if (tst_num_inliers > best_num_inliers)
    {
      // Update circle with largest inlier set.
      best_circle = tst_circle;
      best_num_inliers = tst_num_inliers;

      // Update max iterations.
      double inlier_ratio = static_cast<double>(best_num_inliers) / static_cast<double>(pts.size());
      max_iterations = static_cast<int>(std::log(1 - p_) / std::log(1 - inlier_ratio*inlier_ratio*inlier_ratio));
    }
  }
  // Store number of iterations for visualization.
  last_number_of_iterations_ = iterations;

  return best_circle;
}

Circle CircleEstimator::leastSquaresEstimator(const std::vector<cv::Point2f>& pts)
{
  // Least-squares problem has the form A*p=b
  Eigen::MatrixXd A(pts.size(), 3);
  Eigen::VectorXd b(pts.size());

  for (size_t i = 0; i < pts.size(); ++i)
  {
    A.row(i) << pts[i].x, pts[i].y, 1;
    b(i) = pts[i].x*pts[i].x + pts[i].y*pts[i].y;
  }

  // Determine solve for p
  // See https://eigen.tuxfamily.org/dox-devel/group__LeastSquares.html
  Eigen::Vector3d p = A.colPivHouseholderQr().solve(b);

  // Extract center point and radius from the parameter vector p
  Eigen::Vector2d center_point = 0.5 * p.head<2>();
  double radius = std::sqrt(p(2) + center_point.squaredNorm());

  return Circle{center_point(0), center_point(1), radius};
}

std::vector<cv::Point2f> CircleEstimator::extractInlierPoints(const Circle& circle, const std::vector<cv::Point2f>& pts)
{
  std::vector<cv::Point2f> inlier_pts;

  std::copy_if(
      pts.begin(), pts.end(), std::back_inserter(inlier_pts),
      [&circle, this](const cv::Point2f& point)
      {
        return circle.distance(point) < distance_threshold_;
      });

  return inlier_pts;
}
