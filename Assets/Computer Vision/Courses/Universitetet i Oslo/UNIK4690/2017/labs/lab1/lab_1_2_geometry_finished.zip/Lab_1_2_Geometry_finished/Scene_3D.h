#ifndef LAB_1_SCENE_3D_H
#define LAB_1_SCENE_3D_H

#include "opencv2/viz.hpp"
#include "Eigen/Eigen"
#include "Camera.h"

class Scene_3D
{
public:
  Scene_3D();

  void setWorldPoints(Eigen::Matrix<double, 4, Eigen::Dynamic> points);
  void setCamera(Camera camera);
  void setPlatformPose(Eigen::Matrix4d T_world_body);

  bool isfinished() { return is_finished_; }

  double getBodyLength() { return body_length_; }
  double getBodyWidth() { return body_width_; }
  double getBodyHeight() { return body_height_; }

  void update();

private:
  cv::Mat projectWorldToImage(const Camera& camera);

  cv::viz::Viz3d viz_win_;

  double body_length_;
  double body_width_;
  double body_height_;

  bool is_finished_;

  Eigen::Matrix4Xd world_points_;
};


#endif //LAB_1_SCENE_3D_H
