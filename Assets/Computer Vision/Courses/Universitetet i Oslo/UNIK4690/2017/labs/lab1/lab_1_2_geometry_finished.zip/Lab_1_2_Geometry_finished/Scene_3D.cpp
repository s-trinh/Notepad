#include "Scene_3D.h"
#include "opencv2/opencv.hpp"
#include "opencv2/core/eigen.hpp"

Scene_3D::Scene_3D()
  : viz_win_{"3D Visualization"}
  , body_length_{6.0}
  , body_width_{3.0}
  , body_height_{2.0}
  , is_finished_{false}
{
  // Add world coordinate-axes
  viz_win_.showWidget("World-axes", cv::viz::WCoordinateSystem(2.0));

  // Add world xy-grid
  viz_win_.showWidget("xy-grid", cv::viz::WGrid(
    { 0,0,0 }, { 0,0,1 }, { 0,1,0 },
    cv::Vec2i::all(40), cv::Vec2d::all(1.0),cv::viz::Color::gray()));

  // Add world points
  Eigen::Matrix<double, 4, 8> worldpoints;
  worldpoints.col(0) << 2.0, 2.0, 0, 1;
  worldpoints.col(1) << -2.0, 2.0, 0, 1;
  worldpoints.col(2) << -2.0, -2.0, 0, 1;
  worldpoints.col(3) << 2.0, -2.0, 0, 1;
  worldpoints.col(4) << 2.0, 2.0, 3.0, 1;
  worldpoints.col(5) << -2.0, 2.0, 3.0, 1;
  worldpoints.col(6) << -2.0, -2.0, 3.0, 1;
  worldpoints.col(7) << 2.0, -2.0, 3.0, 1;
  setWorldPoints(worldpoints);

  // Add Body
  viz_win_.showWidget("Body-axis", cv::viz::WCoordinateSystem(1.0));
  cv::viz::WCube body_widget = cv::viz::WCube(
    cv::Vec3d(-0.5*body_length_, -0.5*body_width_, -0.5*body_height_),
    cv::Vec3d(0.5*body_length_, 0.5*body_width_, 0.5*body_height_),
    true, cv::viz::Color::cyan());
  viz_win_.showWidget("Body", body_widget);

  // Create window to show image.
  cv::namedWindow("Projected image");
}

void Scene_3D::update()
{
  if (!is_finished_)
  {
    viz_win_.spinOnce();
  }

  if (cv::waitKey(30) >= 0){
    is_finished_ = true;
    viz_win_.close();
  };
}

void Scene_3D::setPlatformPose(Eigen::Matrix4d T_world_body)
{
  cv::Mat T_world_body_cv;
  cv::eigen2cv(T_world_body, T_world_body_cv);
  cv::Affine3d T_world_body_{T_world_body_cv};
  viz_win_.setWidgetPose("Body-axis", T_world_body_);
  viz_win_.setWidgetPose("Body", T_world_body_);
}

void Scene_3D::setCamera(Camera camera)
{
  cv::Matx33d K;
  cv::eigen2cv(camera.getCalibrationMatrix(), K);
  cv::Mat T_world_camera_cv;
  cv::eigen2cv(camera.getPose(), T_world_camera_cv);
  cv::Affine3d T_world_camera{T_world_camera_cv};

  cv::Mat img = projectWorldToImage(camera);

  viz_win_.showWidget("Camera-axis", cv::viz::WCameraPosition(1.0), T_world_camera);
  viz_win_.showWidget("Camera-frustum", cv::viz::WCameraPosition(K, img, 1.0, cv::viz::Color::red()), T_world_camera);

  cv::imshow("Projected image", img);
}

void Scene_3D::setWorldPoints(Eigen::Matrix<double, 4, Eigen::Dynamic> points)
{
  world_points_ = points;

  Eigen::Matrix<double, Eigen::Dynamic, 4> points_transposed;
  points_transposed = points.transpose();

  cv::Mat points_cv;
  cv::eigen2cv(points_transposed, points_cv);
  cv::Mat world_points_cv = points_cv.reshape(4,1);

  cv::viz::WCloud cloud_widget(world_points_cv, cv::viz::Color::red());
  cloud_widget.setRenderingProperty(cv::viz::POINT_SIZE,6);
  viz_win_.showWidget("points", cloud_widget);
}

cv::Mat Scene_3D::projectWorldToImage(const Camera& camera)
{
  cv::Mat img(camera.getNumRows(), camera.getNumCols(), CV_8UC3, cv::Scalar{});

  Eigen::Matrix3Xd image_points_h = camera.projectWorldPoints(world_points_);

  for (int i=0; i < image_points_h.cols(); ++i)
  {
    int u = static_cast<int>(image_points_h(0, i));
    int v = static_cast<int>(image_points_h(1, i));

    if (u >= 0 && u < img.cols && v >= 0 && v < img.rows)
    {
      img.at<cv::Vec3b>(v, u) = {255, 255, 255};
    }
  }

  return img;
}
