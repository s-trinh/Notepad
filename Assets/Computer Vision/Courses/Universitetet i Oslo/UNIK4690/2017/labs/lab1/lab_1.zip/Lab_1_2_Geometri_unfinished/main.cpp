#include "opencv2/opencv.hpp"
#include "Eigen/Eigen"
#include "Scene_3D.h"
#include "Camera.h"

int main()
{
  const double PI = 3.14159265359;

  // Create object for visualization
  Scene_3D scene;

  // Body
  double x_world_body = 15.0;
  double y_world_body = 10.0;
  double z_world_body = 0.5 * scene.getBodyHeight();
  double yaw_world_body = 210.*PI/180.;
  double pitch_world_body = 0.0*PI/180.;
  double roll_world_body = 0.0*PI/180.;

  // TODO: Compute body pose.
  Eigen::Matrix4d pose_world_body = Eigen::Matrix4d::Identity();

  // Camera
  int num_rows = 120, num_cols = 160;
  double fu = 80, fv = 80, s = 0;

  double x_body_camera = 0.5 * scene.getBodyLength();
  double y_body_camera = 0.0;
  double z_body_camera = 0.5 * scene.getBodyHeight();
  double yaw_body_camera = -90.*PI/180.;
  double pitch_body_camera = 0.0*PI/180.;
  double roll_body_camera = -90.0*PI/180.;

  // TODO: Compute camera pose
  Eigen::Matrix4d pose_world_camera = Eigen::Matrix4d::Identity();

  // TODO: Finish Camera!
  Camera camera{fu, fv, s, num_rows, num_cols, pose_world_camera};

  // Render
  while (!scene.isfinished())
  {
    // TODO: Make the platform/camera move!

    scene.setPlatformPose(pose_world_body);
    camera.setPose(pose_world_camera);
    scene.setCamera(camera);

    scene.update();
  }
}
