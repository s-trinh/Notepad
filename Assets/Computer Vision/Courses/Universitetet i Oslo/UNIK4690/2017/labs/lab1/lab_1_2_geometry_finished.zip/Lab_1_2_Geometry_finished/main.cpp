#include "opencv2/opencv.hpp"
#include "Eigen/Eigen"
#include "Scene_3D.h"
#include "Camera.h"

int main()
{
  const double PI = 3.14159265359;

  // Create object for visualization
  Scene_3D scene;

  // Body
  double x_world_body = 15.0;
  double y_world_body = 10.0;
  double z_world_body = 0.5 * scene.getBodyHeight();
  double yaw_world_body = 210.*PI/180.;
  double pitch_world_body = 0.0*PI/180.;
  double roll_world_body = 0.0*PI/180.;

  Eigen::Matrix3d R_world_body;
  R_world_body = Eigen::AngleAxisd(yaw_world_body, Eigen::Vector3d::UnitZ())*
                 Eigen::AngleAxisd(pitch_world_body, Eigen::Vector3d::UnitY())*
                 Eigen::AngleAxisd(roll_world_body, Eigen::Vector3d::UnitX());
  Eigen::Vector3d t_world_body{x_world_body,y_world_body,z_world_body};
  Eigen::Matrix4d pose_world_body;
  pose_world_body << R_world_body , t_world_body,0,0,0,1;

  // Camera
  int num_rows = 120, num_cols = 160;
  double fu = 80, fv = 80, s = 0;

  double x_body_camera = 0.5 * scene.getBodyLength();
  double y_body_camera = 0.0;
  double z_body_camera = 0.5 * scene.getBodyHeight();
  double yaw_body_camera = -90.*PI/180.;
  double pitch_body_camera = 0.0*PI/180.;
  double roll_body_camera = -90.0*PI/180.;

  Eigen::Matrix3d R_body_camera;
  R_body_camera = Eigen::AngleAxisd(yaw_body_camera, Eigen::Vector3d::UnitZ())*
                  Eigen::AngleAxisd(pitch_body_camera, Eigen::Vector3d::UnitY())*
                  Eigen::AngleAxisd(roll_body_camera, Eigen::Vector3d::UnitX());

  Eigen::Vector3d t_body_camera{x_body_camera,y_body_camera,z_body_camera};
  Eigen::Matrix4d pose_body_camera;
  pose_body_camera << R_body_camera , t_body_camera,0,0,0,1;
  Eigen::Matrix4d pose_world_camera = pose_world_body * pose_body_camera;

  Camera camera{fu, fv, s, num_rows, num_cols, pose_world_camera};

  // Render
  while (!scene.isfinished())
  {
    // Rotate the platform (what happens when the camera is pointing away from the world points?).
    Eigen::Matrix4d rotation = Eigen::Matrix4d::Identity();
    rotation.block<3,3>(0, 0) = Eigen::AngleAxisd(1.0*PI/180., Eigen::Vector3d::UnitZ()).toRotationMatrix();

    pose_world_body *= rotation;

    scene.setPlatformPose(pose_world_body);
    camera.setPose(pose_world_body * pose_body_camera);
    scene.setCamera(camera);

    scene.update();
  }
}
