#ifndef LAB_1_CAMERA_H
#define LAB_1_CAMERA_H

#include "Eigen/Eigen"

namespace Eigen
{
using Matrix34d = Matrix<double, 3, 4>;
}

class Camera
{
public:
  Camera(double fu,
         double fv,
         double s,
         int num_rows,
         int num_cols,
         Eigen::Matrix4d pose_world_camera);

  void setPose(Eigen::Matrix4d pose_world_camera) {
    pose_world_camera_ = pose_world_camera; }

  int getNumRows() const { return num_rows_; }
  int getNumCols() const { return num_cols_; }
  Eigen::Matrix4d getPose() const { return pose_world_camera_; }
  Eigen::Matrix3d getCalibrationMatrix() const { return K_; }

  Eigen::Matrix34d getCameraMatrix() const;
  Eigen::Matrix3Xd projectWorldPoints(Eigen::Matrix4Xd world_points_h) const;

private:
  void createCalibrationMatrix(double fu,
                               double fv,
                               double s,
                               int num_rows,
                               int num_cols);

  int num_rows_;
  int num_cols_;
  Eigen::Matrix4d pose_world_camera_;
  Eigen::Matrix3d K_;
};


#endif //LAB_1_CAMERA_H
