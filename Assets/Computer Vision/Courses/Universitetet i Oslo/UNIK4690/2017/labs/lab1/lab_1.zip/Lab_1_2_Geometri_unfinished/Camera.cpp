#include "Camera.h"

Camera::Camera(double fu,
               double fv,
               double s,
               int num_rows,
               int num_cols,
               Eigen::Matrix4d pose_world_camera)
  : num_rows_{num_rows}
  , num_cols_{num_cols}
  , pose_world_camera_{pose_world_camera}
{
  createCalibrationMatrix(fu, fv, s, num_rows, num_cols);
}

void Camera::createCalibrationMatrix(double fu, double fv, double s, int num_rows, int num_cols)
{
  // TODO: Fill K.
  K_ = Eigen::Matrix3d::Identity();
}

Eigen::Matrix34d Camera::getCameraMatrix() const
{
  // TODO: Compute the Camera Matrix.
  return Eigen::Matrix34d::Identity();
}

Eigen::Matrix3Xd Camera::projectWorldPoints(Eigen::Matrix4Xd world_points_h) const
{
  // TODO: Project world points into image coordinates.
  Eigen::Matrix3Xd img_points_h;
  return img_points_h;
}