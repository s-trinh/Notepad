//
// Created by thm on 26.01.17.
//

#include "Camera.h"

Camera::Camera(double fu,
               double fv,
               double s,
               int num_rows,
               int num_cols,
               Eigen::Matrix4d pose_world_camera)
  : num_rows_{num_rows}
  , num_cols_{num_cols}
  , pose_world_camera_{pose_world_camera}
{
  createCalibrationMatrix(fu, fv, s, num_rows, num_cols);
}

void Camera::createCalibrationMatrix(double fu, double fv, double s, int num_rows, int num_cols)
{
  K_ <<  fu,   s, 0.5 * num_rows,
        0.0,  fv, 0.5 * num_cols,
        0.0, 0.0, 1.0;
}

Eigen::Matrix34d Camera::getCameraMatrix() const
{
  Eigen::Matrix4d pose_camera_world = pose_world_camera_.inverse();
  return K_ * pose_camera_world.block<3,4>(0, 0) ;
}

Eigen::Matrix3Xd Camera::projectWorldPoints(Eigen::Matrix4Xd world_points_h) const
{
  Eigen::Matrix3Xd img_points_h = getCameraMatrix() * world_points_h;
  img_points_h.array().rowwise() /= img_points_h.array().row(2);
  return img_points_h;
}
