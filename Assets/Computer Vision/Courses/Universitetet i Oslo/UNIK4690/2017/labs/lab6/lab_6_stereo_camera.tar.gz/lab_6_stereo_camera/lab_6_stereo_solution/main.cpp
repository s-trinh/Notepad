#include "stereo_calibration.h"
#include "sparse_stereo_matcher.h"
#include "opencv2/opencv.hpp"
#include "opencv2/xfeatures2d/nonfree.hpp"

int main()
{
  // The calibration files will be in the stereo_calibration folder in a typical CLion setup.
  std::string intrinsic_filename = "../stereo_calibration/intrinsics.yml";
  std::string extrinsic_filename = "../stereo_calibration/extrinsics.yml";

  // Make sure that these IDs are correct.
  const int left_camera_id = 1;
  const int right_camera_id = 2;

  // Connect to the cameras.
  cv::VideoCapture left_cap{left_camera_id};
  cv::VideoCapture right_cap{right_camera_id};

  if (!left_cap.isOpened()) { throw std::runtime_error{"Could not open left camera"}; }
  if (!right_cap.isOpened()) { throw std::runtime_error{"Could not open right camera"}; }

  // Capture a frame to get img size.
  cv::Mat test_frame;
  left_cap >> test_frame;
  cv::Size img_size = test_frame.size();

  // Construct calibration object.
  StereoCalibration calibration{intrinsic_filename, extrinsic_filename, img_size};

  // Construct sparse matcher.
  cv::Ptr<cv::Feature2D> detector = cv::xfeatures2d::SIFT::create();
  cv::Ptr<cv::Feature2D> desc_extractor = cv::xfeatures2d::SIFT::create();
  SparseStereoMatcher stereo_matcher{detector, desc_extractor};

  // Setup windows.
  std::string matching_win{"Stereo matching"};
  cv::namedWindow(matching_win);
  std::string depth_win{"Stereo depth"};
  cv::namedWindow(depth_win);
  cv::viz::Viz3d viz3d{"3D Visualization"};
  viz3d.showWidget("Camera-axis", cv::viz::WCameraPosition(1.0));
  viz3d.showWidget("Camera-frustum", cv::viz::WCameraPosition(cv::Matx33f(calibration.K_left()), 1.0));

  for (;;)
  {
    StereoPair stereo_raw;

    // Use VideoCapture::grab() to make sure that the images are captured as near in time as possible.
    left_cap.grab();
    right_cap.grab();

    // The captured images are retrieved with VideoCapture::retrieve().
    bool left_ok = left_cap.retrieve(stereo_raw.first);
    bool right_ok = right_cap.retrieve(stereo_raw.second);

    if (!left_ok) { throw std::runtime_error{"Could not capture from left camera"}; }
    if (!right_ok) { throw std::runtime_error{"Could not capture from right camera"}; }

    // Rectify images.
    StereoPair stereo_rectified;
    calibration.rectify(stereo_raw, stereo_rectified);

    // Perform sparse matching.
    stereo_matcher.match(stereo_rectified);

    cv::Mat matching_vis;
    cv::drawMatches(stereo_rectified.first, stereo_matcher.keypoints_left(),
                    stereo_rectified.second, stereo_matcher.keypoints_right(),
                    stereo_matcher.matches(), matching_vis,
                    {0,255,0}, {0,0,255}, {}, cv::DrawMatchesFlags::DEFAULT);
    cv::imshow(matching_win, matching_vis);

    // Get points with disparities.
    const std::vector<cv::Vec3d>& point_disparities = stereo_matcher.point_disparities();
    if (point_disparities.size() > 0)
    {
      // Compute depth in meters for each point.
      cv::Mat depth_vis = stereo_rectified.first.clone();

      const double f = calibration.f();
      const double bx = calibration.baseline();
      for (auto& d_vec : stereo_matcher.point_disparities())
      {
        cv::Point pos{static_cast<int>(d_vec[0]), static_cast<int>(d_vec[1])};
        cv::drawMarker(depth_vis, pos, {0,255,0}, cv::MARKER_CROSS, 5);

        std::stringstream depth_text;
        depth_text << std::fixed << std::setprecision(2) << f * bx / d_vec[2];
        cv::putText(depth_vis, depth_text.str(), pos, cv::FONT_HERSHEY_PLAIN, 1.0, {0, 255, 0});
      }
      cv::imshow(depth_win, depth_vis);

      // Compute and visualize 3D point cloud.
      std::vector<cv::Vec3d> world_points;
      cv::perspectiveTransform(point_disparities, world_points, calibration.Q());
      cv::viz::WCloud pointcloud(world_points);
      pointcloud.setRenderingProperty(cv::viz::POINT_SIZE,6);
      viz3d.showWidget("points", pointcloud);
    }

    // Draw visualizations.
    viz3d.spinOnce(10);
    if (cv::waitKey(10) >= 0)
    {
      break;
    }
  }
}