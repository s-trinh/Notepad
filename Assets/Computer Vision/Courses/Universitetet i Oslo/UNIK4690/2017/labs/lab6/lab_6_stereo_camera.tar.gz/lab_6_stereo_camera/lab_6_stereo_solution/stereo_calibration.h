#ifndef STEREO_CALIBRATION_H
#define STEREO_CALIBRATION_H

#include "opencv2/core.hpp"

// StereoPair.first is the left stereo image, StereoPair.second is the right stereo image.
using StereoPair = std::pair<cv::Mat, cv::Mat>;

class StereoCalibration
{
public:
  StereoCalibration(const std::string& intrinsic_filename,
                    const std::string& extrinsic_filename,
                    const cv::Size& img_size);

  void rectify(const StereoPair& raw, StereoPair& rectified);

  double baseline() { return 1.f/Q_.at<double>(3, 2); }
  double f() { return Q_.at<double>(2, 3); }

  cv::Size img_size() { return img_size_; }
  const cv::Mat& Q() { return Q_; }
  const cv::Mat& K_left() { return K_left_; }
  const cv::Mat& distortion_left() { return distortion_left_; }
  const cv::Mat& K_right() { return K_right_; }
  const cv::Mat& distortion_right() { return distortion_right_; }

private:
  void computeRectificationMapping();

  cv::Size img_size_;
  cv::Mat Q_;

  // Intrinsics.
  cv::Mat K_left_;
  cv::Mat distortion_left_;
  cv::Mat K_right_;
  cv::Mat distortion_right_;

  // Extrinsics.
  cv::Mat R_;
  cv::Mat t_;

  // Rectification mappings.
  cv::Mat map_left_x_;
  cv::Mat map_left_y_;
  cv::Mat map_right_x_;
  cv::Mat map_right_y_;
};

#endif //STEREO_CALIBRATION_H
