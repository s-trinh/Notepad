#include "stereo_calib.h"
#include "opencv2/opencv.hpp"

// StereoPair.first is the left stereo image, StereoPair.second is the right stereo image.
using StereoPair = std::pair<cv::Mat, cv::Mat>;

cv::Mat findAndDrawChessboard(const cv::Size& chessboard_size, const cv::Mat& frame)
{
  const int chessBoardFlags = cv::CALIB_CB_ADAPTIVE_THRESH | cv::CALIB_CB_NORMALIZE_IMAGE | cv::CALIB_CB_FAST_CHECK;

  cv::Mat view = frame.clone();
  cv::Mat corners;

  bool found = findChessboardCorners(view, chessboard_size, corners, chessBoardFlags);
  drawChessboardCorners(view, chessboard_size, corners, found);

  return view;
}

void visualizeChessBoards(cv::Mat& view, const cv::Size& chessboard_size, const StereoPair& stereo_pair)
{
  cv::hconcat(
      findAndDrawChessboard(chessboard_size, stereo_pair.first),
      findAndDrawChessboard(chessboard_size, stereo_pair.second),
      view);
}

void addHelpText(cv::Mat& img)
{
  std::string text{"Press <space> to capture pair, <q> to save and quit"};
  cv::putText(img, text, {10, 20}, cv::FONT_HERSHEY_PLAIN, 1.0, {0, 0, 255});
}

void addNumberOfImagesText(cv::Mat& img, size_t num_images)
{
  std::stringstream text;
  text << "Number of captured images: " << num_images;
  cv::putText(img, text.str(), {10, 40}, cv::FONT_HERSHEY_PLAIN, 1.0, {0, 0, 255});
}

std::vector<std::string> writeImages(const std::vector<StereoPair>& stereo_images)
{
  std::vector<std::string> img_filenames;

  for (size_t i=0; i<stereo_images.size(); ++i)
  {
    std::stringstream left_filename;
    left_filename << "stereo_left_" << i << ".png";
    cv::imwrite(left_filename.str(), stereo_images[i].first);
    img_filenames.push_back(left_filename.str());

    std::stringstream right_filename;
    right_filename << "stereo_right_" << i << ".png";
    cv::imwrite(right_filename.str(), stereo_images[i].second);
    img_filenames.push_back(right_filename.str());
  }

  return img_filenames;
}

int main()
{
  int left_camera_id = 1;
  int right_camera_id = 2;

  cv::Size chessboard_size = {7, 5};
  float square_size = 0.03;

  cv::VideoCapture left_cap{left_camera_id};
  cv::VideoCapture right_cap{right_camera_id};

  if (!left_cap.isOpened())
  {
    throw std::runtime_error{"Could not open left camera"};
  }
  if (!right_cap.isOpened())
  {
    throw std::runtime_error{"Could not open right camera"};
  }

  std::string win_name{"Stereo capture"};
  cv::namedWindow(win_name);

  std::vector<StereoPair> stereo_images;
  for (;;)
  {
    StereoPair stereo_img;

    // Use VideoCapture::grab() to make sure that the images are captured as near in time as possible.
    left_cap.grab();
    right_cap.grab();

    // The captured images are retrieved with VideoCapture::retrieve().
    bool left_ok = left_cap.retrieve(stereo_img.first);
    bool right_ok = right_cap.retrieve(stereo_img.second);

    if (!left_ok) { throw std::runtime_error{"Could not capture from left camera"}; }
    if (!right_ok) { throw std::runtime_error{"Could not capture from right camera"}; }

    // Find chessboard. The corners will not be used, but will at least give an impression of the applicability
    // of the stereo capture for calibration.
    cv::Mat view;
    visualizeChessBoards(view, chessboard_size, stereo_img);
    addHelpText(view);
    addNumberOfImagesText(view, stereo_images.size());
    cv::imshow(win_name, view);

    char key = static_cast<char>(cv::waitKey(10));
    if (key == ' ')
    {
      stereo_images.push_back(stereo_img);
    }
    else if (key == 'q')
    {
      break;
    }
  }

  // Write the images to file and run stereo calibration.
  std::vector<std::string> img_filenames = writeImages(stereo_images);
  StereoCalib(img_filenames, chessboard_size, square_size, false, true, true);
}