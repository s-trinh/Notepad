#ifndef STEREO_CALIB_H
#define STEREO_CALIB_H

#include "opencv2/core.hpp"

void StereoCalib(const std::vector<std::string>& imagelist, cv::Size boardSize, float squareSize,
                 bool displayCorners = false, bool useCalibrated=true, bool showRectified=true);

#endif //STEREO_CALIB_H
