#include "sparse_stereo_matcher.h"

SparseStereoMatcher::SparseStereoMatcher(cv::Ptr<cv::Feature2D>& detector,
                                         cv::Ptr<cv::Feature2D>& desc_extractor,
                                         int max_num_features,
                                         double max_ratio)
    : detector_{detector}
    , desc_extractor_{desc_extractor}
    , matcher_{cv::makePtr<cv::BFMatcher>(desc_extractor_->defaultNorm())}
    , max_num_features_{max_num_features}
    , max_ratio_{max_ratio}
{}

void SparseStereoMatcher::match(const StereoPair& stereo_img)
{
  // Detect and describe features in the left image.
  keypoints_left_.clear();
  detector_->detect(stereo_img.first, keypoints_left_);
  cv::KeyPointsFilter::retainBest(keypoints_left_, max_num_features_);
  cv::Mat query_descriptors;
  desc_extractor_->compute(stereo_img.first, keypoints_left_, query_descriptors);

  // Detect and describe features in the right image.
  keypoints_right_.clear();
  detector_->detect(stereo_img.second, keypoints_right_);
  cv::KeyPointsFilter::retainBest(keypoints_right_, max_num_features_);
  cv::Mat train_descriptors;
  desc_extractor_->compute(stereo_img.second, keypoints_right_, train_descriptors);

  // Match features
  std::vector<std::vector<cv::DMatch>> matches;
  matcher_->knnMatch(query_descriptors, train_descriptors, matches, 2);

  extractGoodMatches(matches);
  computeDisparities();
}

void SparseStereoMatcher::extractGoodMatches(const std::vector<std::vector<cv::DMatch>>& matches)
{
  good_matches_.clear();

  for (size_t i = 0; i < matches.size(); ++i)
  {
    const cv::DMatch& best_match = matches[i][0];
    const cv::DMatch& second_best_match = matches[i][1];

    bool is_ratio_ok = best_match.distance < second_best_match.distance * max_ratio_;
    bool is_epipolar_ok = std::abs(keypoints_right_[best_match.trainIdx].pt.y
                                   - keypoints_left_[best_match.queryIdx].pt.y) < 0.5f;
    if (is_ratio_ok && is_epipolar_ok)
    {
      good_matches_.push_back(best_match);
    }
  }
}

void SparseStereoMatcher::computeDisparities()
{
  point_disparities_.clear();
  for (auto& match : good_matches_)
  {
    const cv::Point2f& left_point = keypoints_left_[match.queryIdx].pt;
    const cv::Point2f& right_point = keypoints_right_[match.trainIdx].pt;

    float disparity = left_point.x - right_point.x;

    point_disparities_.push_back({left_point.x, left_point.y, disparity});
  }
}
