#include "multivariate_normal_model.h"
#include "opencv2/highgui.hpp"
#include <iostream>

int main()
{
  cv::VideoCapture cap{1};
  if (!cap.isOpened())
  {
    std::cerr << "Could not open VideoCapture\n";
    return EXIT_FAILURE;
  }

  lab9::MultivariateNormalModel model;

  const std::string win_name_input{"Lab 9: Segmentation - Input"};
  const std::string win_name_result{"Lab 9: Segmentation - Probability density"};

  cv::namedWindow(win_name_input, cv::WINDOW_NORMAL);
  cv::namedWindow(win_name_result, cv::WINDOW_NORMAL);

  const int max_threshold{255};
  int current_threshold{240};
  bool use_otsu{false};

  cv::createTrackbar("Threshold", win_name_input, &current_threshold, max_threshold);

  for (cv::Mat frame; cap.read(frame); )
  {
    cv::Mat current_image = frame.clone();
    cv::Rect sampling_rectangle = lab9::getSamplingRectangle(current_image.size());

    if (model.isTrained())
    {
      cv::Mat density_raw = model.computeDensities(frame);
      density_raw.convertTo(density_raw, CV_8U, 255);
      cv::Mat density_segmented = lab9::segmentImage(density_raw, current_threshold, use_otsu);

      cv::imshow(win_name_result, density_raw);
      current_image.setTo(cv::Scalar{0, 255, 0}, density_segmented);
    }

    lab9::drawSamplingRectangle(current_image, sampling_rectangle);
    cv::imshow(win_name_input, current_image);

    char key = static_cast<char>(cv::waitKey(30));
    if (key == ' ')
    {
      cv::Mat samples = lab9::extractTrainingSamples(frame, sampling_rectangle);
      model.performTraining(samples);
    }
    else if (key == 'o')
    {
      use_otsu = !use_otsu;
      if (use_otsu)
        std::cout << "Using Otsu\n";
      else
        std::cout << "Not using Otsu\n";
    }
    else if (key >= 0)
    { break; }
  }

}
