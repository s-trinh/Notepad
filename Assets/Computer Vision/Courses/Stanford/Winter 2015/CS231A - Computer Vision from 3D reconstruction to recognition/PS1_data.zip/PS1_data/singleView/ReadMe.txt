function v = getVanishingPoint(im)
% An interactive function that facilitates computing a 
% vanishing point given an image 'im' as input.
% Usage: Select two points from the first line and then two more for the
% second line, press enter after selecting the 4 points on the two lines
% Output v is a vanishing point such that: (v(1),v(2)) = (x,y)
Vanishing point is calculated in this way:
Let P1, P2 belong to line P and Q1, Q2 belong to line Q. Let P||Q.
Using the respective points in the two lines P and Q, we compute their line equations in 2D.
We then extrapolate the lines till they meet to find the Vanishing Points.


