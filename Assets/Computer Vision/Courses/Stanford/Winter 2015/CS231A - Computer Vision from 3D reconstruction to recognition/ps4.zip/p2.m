% Bag of Visual Words for image classification

close all;

% ----------------------------------------------------------------------
%                                                     User configuration
% ----------------------------------------------------------------------

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE STARTS HERE
%
% Make sure to install vlfeat and set VLFEAT_PATH to your vlfeat root path.
% Set the number of image classes, N_CLASSES, to 3 to finish your
% implementation, make sure it's bug-free, then increase it to 10
% for full-blown run. N_WORDS_CHOICES controls different number of
% words to use. MAX_LEVEL_CHOICES controls the number of spatial pyramid
% levels to use.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
VLFEAT_PATH = ''; % e.g. '/path/to/vlfeat'
N_CLASSES = 2;
N_WORDS_CHOICES = 400:200:400; % e.g. 400:100:800
MAX_LEVEL_CHOICES = 0:0; % e.g. 0:2
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE ENDS HERE
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ----------------------------------------------------------------------
%                                                   System configuration
% ----------------------------------------------------------------------

% Add function search path
addpath(fullfile(VLFEAT_PATH, 'toolbox'));
addpath('./problem_2');
% addpath('./problem_2/xtick'); % For some MATLAB, the xtick rotate crashes

vl_setup;
vl_twister('state',153);
randn('state', 153);
rand('state', 153);

DSIFT_OPTS = {'Step', 5};
DATA_PATH = './caltech101_subset';

for N_WORDS_iter = 1:length(N_WORDS_CHOICES)
  for MAX_LEVEL_iter = 1:length(MAX_LEVEL_CHOICES)
    tic;

    N_WORDS = N_WORDS_CHOICES(N_WORDS_iter);
    MAX_LEVEL = MAX_LEVEL_CHOICES(MAX_LEVEL_iter);

    % Setup images and divide images into training set and test set
    [classes, train_set, test_set, image_paths, image_classes] = ...
        config(N_CLASSES, DATA_PATH);

    % Visualize images
    visualize_images(image_classes, image_paths, train_set,...
                     'A Few Training Examples');
    visualize_images(image_classes, image_paths, test_set,...
                     'A Few Test Examples');

    % ----------------------------------------------------------------------
    %                                            Extract feature description
    % ----------------------------------------------------------------------

    train_features = extract_dense_sift(image_paths(train_set), DSIFT_OPTS);

    % ----------------------------------------------------------------------
    %                                          Build Visual Words Dictionary
    % ----------------------------------------------------------------------

    [dictionary, word_indice] = create_dictionary(train_features, N_WORDS);

    % ----------------------------------------------------------------------
    %                                       Image representation (histogram)
    % ----------------------------------------------------------------------

    histograms = create_histograms(image_paths, dictionary, N_WORDS,...
                                   DSIFT_OPTS, MAX_LEVEL);

    train_histograms = histograms(:, train_set);
    train_classes = image_classes(train_set);

    test_histograms = histograms(:, test_set);
    test_classes = image_classes(test_set);

    % --------------------------------------------------------------------
    %                                         Machine learning (train SVM)
    % --------------------------------------------------------------------

    [W, b] = train_svms_kernel(train_histograms, train_classes);

    % --------------------------------------------------------------------
    %                                          Machine learning (test SVM)
    % --------------------------------------------------------------------

    [test_accuracy, test_prediction] =...
        test_svms(W, b, test_histograms, test_classes);
    [train_accuracy, train_prediction] =...
        test_svms(W, b, train_histograms, train_classes);

    confusion_mat = create_confusion_matrix(test_classes, test_prediction);

    % --------------------------------------------------------------------
    %                                                       Visualization
    % --------------------------------------------------------------------

    iter_title = sprintf('N WORDS: %d, MAX LEVEL: %d, TEST ACC: %.2f',...
        N_WORDS, MAX_LEVEL, test_accuracy * 100);
    fprintf('%s test accuracy %f\n', iter_title, test_accuracy);
    fprintf('%s train accuracy %f\n', iter_title, train_accuracy);
    figure; colormap = cool(256);
    % Normalize the predictions for visualization.
    confusion_mat = bsxfun(@rdivide, confusion_mat, sum(confusion_mat, 1));
    imagesc(confusion_mat);
    title(iter_title);
    set(gca, 'XTick', 1:N_CLASSES, 'YTick', 1:N_CLASSES)
    set(gca, 'XTickLabel', classes, 'YTickLabel', classes)
    % xticklabel_rotate([], 90, [], 'FontSize', 14);
    toc;
  end % MAX_LEVEL
end % N_WORDS
