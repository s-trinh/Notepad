function [dictionary, word_indices] = create_dictionary(train_features, N_WORDS)
%CREATE_DICTIONARY Create BOW dictionary by dense SIFT features.
%
% INPUT train_features: D x F dense SIFT features of the training set, where
%                       D is the size of a SIFT feature and F is the number
%                       of features in total.
%       N_WORDS: number of words in the dictionary.
%
% OUTPUT dictionary: the visual dictionary. D x N_WORDS matrix, where
%                    each column is a D-dimensional word, with N_WORDS words
%                    in total.
%        word_indice: assignment of features to the words. F x 1 matrix,
%                     where the i-th element is the index of assigned word
%                     of the i-th feature, with F features in total.

fprintf('creating dictionary...\n');

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE STARTS HERE
%
% Use VLFeat's version of kmeans() to create dictionary. For faster clustering,
% consider using Elkan's algorithm, and set number of iterations,
% e.g. 50 iterations.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE ENDS HERE
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
