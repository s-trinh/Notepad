function [classes, train_set, test_set, images, image_class] = ...
    config(N_CLASSES, DATA_PATH)
%% Donwload dataset and configure setting.
%
% If the Caltech 101 subset directory doesn't exist, download from the
% web and set the classes
%
% Input N_CLASSES: number of classes that you use from caltecch 101

if ~exist(DATA_PATH, 'dir')
  subset_url = ['http://cs231a.stanford.edu/hw/caltech101_subset.tar.gz'];
  fprintf(['Downloading Caltech-101 subset data to %s.\n',...
          'Do not stop or kill the process\n'], DATA_PATH);
  urlwrite(subset_url, [DATA_PATH, '.tar.gz']);
  untar([DATA_PATH, '.tar.gz']);
end

N_TRAIN = 40;
N_TEST = 20;

classes = {'bonsai', 'kangaroo', 'buddha', 'ewer', 'grand_piano', 'car_side','ketch', 'menorah', 'sunflower', 'trilobite'};
classes = classes(1:N_CLASSES);

images = {};
image_class = {};
for ci = 1:length(classes)
  ims = dir(fullfile(DATA_PATH, classes{ci}, '*.jpg'))';
  ims = vl_colsubset(ims,  N_TRAIN + N_TEST);
  ims = cellfun(@(x)fullfile(DATA_PATH, classes{ci}, x), {ims.name},...
                'UniformOutput', false);
  images = {images{:}, ims{:}};
  image_class{end + 1} = ci * ones(1, length(ims));
end
classes = cellfun(@(x) strrep(x, '_', ' '), classes, 'UniformOutput', false);

train_set = find(mod(0:length(images) - 1, N_TRAIN + N_TEST) < N_TRAIN);
test_set = setdiff(1:length(images), train_set);
image_class = cat(2, image_class{:});
