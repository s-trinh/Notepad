function confusion_mat = create_confusion_matrix(gt_classes, pred_classes)
%CREATE_CONFUSION_MATRIX create a confusion matrix
%
% INPUT gt_classes : length-M ground truth classes vector
%
%       pred_classes : length-M prediction classes vector
%
% OUTPUT confusion_mat : For N = lengtu(unique(gt_classes)), N x N matrix 
%                       where confusion_mat(i,j) represents
%                       the count of instances whose ground truth labels 
%                       are the i th class and predicted as the j th class.

N_CLASSES = numel(unique(gt_classes));
confusion_mat = zeros(N_CLASSES, N_CLASSES);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE STARTS HERE
%
% Fill out the confusion matrix. confusion_mat(i,j) represents the 
% count of instaneces whose ground truth labels are the i th class 
% and predicted as the j th class.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE ENDS HERE
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
