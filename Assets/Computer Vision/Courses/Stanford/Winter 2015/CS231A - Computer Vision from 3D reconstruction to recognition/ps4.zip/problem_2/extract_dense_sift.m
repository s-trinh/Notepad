function features = extract_dense_sift(image_paths, DSIFT_OPTS)
%EXTRACT_DENSE_SIFT extract dense sift features.
%
% INPUT image_paths: 1 x N cell of image paths, where N is the number of images
%                    to extract features.
%       DSIFT_OPTS: 1 x P cell of parameters (name-value pairs) for extracting
%                  dense SIFT features by vl_dsift().
%
% OUTPUT features: the extracted dense SIFT features. D x F matrix, where
%                  each column is a D-dimensional feature and F is the
%                  number of features extracted in total. Note that F does not
%                  equal to the number of images, since multiple features
%                  are extracted from each image.

fprintf('extracting dense SIFT...\n');

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE STARTS HERE
%
% Extract dense SIFT feature by vl_dsift() in the VLFeat library. Use the
% parameters specified by DSIFT_OPTS. After features are extracted from
% all images, randomly select only 10,000 features out of them to return.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE ENDS HERE
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Convert the extracted features into 32bit floating point real numbers
features = single(features);
