function [W, b] = train_svms_kernel(train_features, train_classes)
%TRAIN_SVMS_KERNEL train multi-class 1-vs-all svms with kernel
%
% This is a wrapper function that converts features with a homogeneous kernel
% before training a multi-class svm.
% 
% INPUT train_features: the features to be trained. D x F matrix, where each
%                       column is D-dimensional feature, F features in total.
%       train_classes: the classes (labels) corresponding to the training
%                      features. 1 x F matrix, with the i-th element
%                      corresponding to the i-th feature.
% OUTPUT W, b: svm matrix that classifies by (W * x + b)

psix = vl_homkermap(train_features, 1, 'kchi2', 'gamma', .5);
[W, b] = train_svms(psix, train_classes);

end
