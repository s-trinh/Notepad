function histograms =...
    create_histograms(image_paths, dictionary, N_WORDS, DSIFT_OPTS, MAX_LEVEL)
%CREATE_HISTOGRAMS represent images as histogram given a dictionary.
%
% INPUT image_paths: 1 x N cell of image paths, where N is the number of images
%                    to represent.
%       dictionary: the visual dictionary. D x N_WORDS matrix, where
%                   each column is a D-dimensional word, with N_WORDS words
%                   in total.
%       N_WORDS: number of words in the dictionary.
%       DSIFT_OPTS: 1 x P cell of parameters (name-value pairs) for extracting
%                   dense SIFT features by vl_dsift().
%       MAX_LEVEL: number of levels to use for the spatial pyramid. E.g.
%                  if MAX_LEVEL == 2, it means the histograms are
%                  constructed by concatenating histograms of each subdivision
%                  from 0-level, 1-level, and 2-level pyramid.
%
% OUTPUT histograms: the collection of histogram of each image.
%                    (k * N_WORDS) x N matrix, where the i-th column is the
%                    histogram that represents the i-th image. Each column is
%                    a (k * N_WORDS) x 1 histogram computed by concatenating
%                    all histograms from each sub-division of each level of
%                    the spatial pyramid, where k is the number of
%                    sub-divisions in total. For convenience, in the code
%                    we give you N_BINS = k * N_WORDS. Therefore, the output is
%                    an N_BINS x N matrix.

fprintf('creating histograms...\n');

N_BINS = sum(4 .^ (0:MAX_LEVEL)) * N_WORDS; % number of bins (see header)

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE STARTS HERE
%
% For each image, collect the concatenated histogram of the spatial pyramid
% with specified number of levels. Use spatial_pyramid_single() to compute
% histogram of a single level.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE ENDS HERE
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

assert(size(histograms, 1) == N_BINS &&...
       size(histograms, 2) == length(image_paths),...
       ['Your histogram has incorrect size. Please check the header',...
       ' instructions of create_histograms.m']);
