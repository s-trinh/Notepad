function image = read_image(image_path)
%READ_IMAGE Read and normalize (to 512 pixel height) an image.
%
% INPUT image_path: a string, the image path.
% OUTPUT image: the normalized image read from the given path.

image = imread(image_path);
image = imresize(image, [512 NaN]);
if size(image, 3) > 1
  image = rgb2gray(image);
end
image = im2single(image);

end
