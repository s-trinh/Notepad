function [accuracy, predictions] = test_svms(W, b, test_features, groundtruth)
%TEST_SVMS Use trained svm to classify images and output its accuracy.
%
% INPUT W, b: svm matrix
%       test_features: features of the test set. D x F matrix, where each
%                       column is D-dimensional feature, F features in total.
%       test_classes: the classes (labels) corresponding to the testing
%                     features. 1 x F matrix, with the i-th element
%                     corresponding to the i-th feature.
%       groundtruth: groundtruth classes (label) of the test set. 1 x N matrix,
%                    where N is the number of images in the test set.
% OUTPUT accuracy: the accuracy of the classification.

psix = vl_homkermap(test_features, 1, 'kchi2', 'gamma', .5);
test_scores = W * psix + b * ones(1, size(psix, 2));
[drop, predictions] = max(test_scores, [], 1);
accuracy = mean(predictions == groundtruth);
