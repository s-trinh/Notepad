function grid_histogram =...
    spatial_pyramid_single(feature_pos, assignments, image_size, N_WORDS, level)
% GRID_HISTOGRAM Create histogram of the spatial pyramid of the given level.
%
% INPUT feature_pos: the features position. 2 x F matrix, where F is the
%                    number of features. The i-th column is the (x, y)
%                    coordinate of the center of the i-th feature.
%       assignments: the index of assigned word of each feature. F x 1 matrix,
%                    where F is the number of features, and the i-th element
%                    is the index of assinged word of the i-th feature.
%       image_size: size of the image, same format as Matlab size(im) function.
%       N_WORDS: number of words in the dictionary.
%       level: level of the spatial pyramid. A level-0 pyramid is the same as
%              the original image; a level-1 pyramid is the image subdivided
%              by 2x2 grids.
%
% OUTPUT grid_histogram: the histogram concatenated by histograms of each
%                        grid in this spatial pyramid.
%                        (h * N_WORDS) x 1 matrix, where h is the total
%                        number of histograms that are concatenated.
%                        For convenience, in the code we give you
%                        N_BINS_SINGLE = h * N_WORDS. Therefore, the output
%                        is an N_BINS_SINGLE * 1 matrix.

N_BINS_SINGLE = (4 ^ level) * N_WORDS; % number of bins (see header)

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE STARTS HERE
%
% Compute the histogram of a spatial pyramid level. For example, for a level-2
% pyramid, the histogram should be concatenation of histograms extracted by
% each of the 2x2 subdivision of the image. Utilize the feature's position to
% achieve this. Before each histogram is concatenated, you need to normalize
% the histogram so that it adds up to 1, so it becomes a probability
% distribution of bin counts.
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% YOUR CODE ENDS HERE
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

assert(size(grid_histogram, 1) == N_BINS_SINGLE &&...
       size(grid_histogram, 2) == 1,...
       ['Your grid histogram has incorrect size. Please check the header',...
       ' instructions of spatial_pyramid_single.m']);

end
