function visualize_images(classes, images, image_set, caption)
% Given classes and image paths, load few images at random
% and visualize.
%
% Input. classes    : class index of images
%        images     : path to images
%        image_set  : index of the images (ie, train set)
%        caption    : The title of the plot
classes = classes(image_set);
images = images(image_set);
images_per_class = 5;
num_classes = max(classes);
figure;
for class_idx=1:num_classes
    img_paths = randsample(images(classes==class_idx), images_per_class);
    for img_idx=1:length(img_paths)
        subplot(num_classes, images_per_class, (class_idx-1)*images_per_class+img_idx);
        imagesc(imread(img_paths{img_idx}));
        axis off;
    end
end
% suptitle(caption);
drawnow;
