function [W, b] = train_svms(train_features, train_classes, reg)
%TRAIN_SVM train multi-class 1-vs-all svms

if nargin < 3
    reg = 0.1;
end

classes = unique(train_classes);
n_class = numel(classes);
W = zeros(n_class, size(train_features,1))';
b = zeros(n_class, 1);

for class_idx = 1:numel(classes)
    y_class = ones(numel(train_classes), 1);
    y_class(classes(class_idx) ~= train_classes) = -1;
    [W(:,class_idx), b(class_idx)] = vl_svmtrain(train_features, y_class, reg);
end

W = W';
