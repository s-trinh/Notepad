function F = computeF( pt1, pt2 )
%computeF
% 
% INPUT:
%   p1: 6 * 2 matrix, each row is an (x, y) point
%   p2: 6 * 2 matrix, each row is an (x, y) point
% where the first four corresponding points are from
% the same 3D plane and the last two corresponding
% points are out of that 3D plane.
% 
% OUTPUT:
%   F: 3 * 3 fundamental matrix
% 
% This function computes the fundamental matrix such
% that p1' * F * p2 = 0.
% 
%

if (size(pt1, 1) ~= 6 || size(pt2, 1) ~= 6),
    error('Wrong number of points.');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%                              YOUR CODE HERE                             %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


end
