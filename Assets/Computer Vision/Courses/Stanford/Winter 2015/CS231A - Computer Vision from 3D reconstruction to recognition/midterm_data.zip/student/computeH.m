function H = computeH ( p1, p2 )
%computeH 
% This function computes the homography H such that
% p2 = H * p1 using normalized DLT algorithm.
%
% INPUT:
%   p1: N * 2 matrix, each row is an (x, y) point
%   p2: N * 2 matrix, each row is an (x, y) point
% 
% OUTPUT:
%   H: 3 * 3 projective transformation
%
N = size(p1, 1);

if N < 4,
    error('Insufficient number of points.');
end

% Normalization
s1 = 1 ./ std(p1);
c1 = s1 .* mean(p1);
T1 = eye(3, 3);
T1(1, 1) = s1(1);
T1(2, 2) = s1(2);
T1(1, 3) = -c1(1);
T1(2, 3) = -c1(2);

s2 = 1 ./ std(p2);
c2 = s2 .* mean(p2);
T2 = eye(3, 3);
T2(1, 1) = s2(1);
T2(2, 2) = s2(2);
T2(1, 3) = -c2(1);
T2(2, 3) = -c2(2);

pt1 = (T1 * [p1'; ones(1, N)])';
pt2 = (T2 * [p2'; ones(1, N)])';

% DLT
A = zeros(2 * N, 9);
for i = 1 : N,
    A(2*(i-1) + 1, :) = [zeros(1, 3), -pt1(i, :), pt2(i, 2) * pt1(i, :) ];
    A(2*(i-1) + 2, :) = [pt1(i, :), zeros(1, 3), -pt2(i, 1) * pt1(i, :) ];
end

[~, ~, V] = svd(A);
h = V(:, end);
H = reshape(h, 3, 3)';

H = pinv(T2) * H * T1;

end

