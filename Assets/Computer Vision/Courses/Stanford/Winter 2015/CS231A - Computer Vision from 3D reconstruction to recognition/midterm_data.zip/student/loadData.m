function loadData ()

load('p1.mat');
load('p2.mat');

I1 = imread('image1.bmp');
figure;
imshow(I1);
hold on;
plot(p1(:, 1), p1(:, 2), 'ro');
hold off;

I2 = imread('image2.bmp');
figure;
imshow(I2);
hold on;
plot(p2(:, 1), p2(:, 2), 'ro');
hold off;

end

